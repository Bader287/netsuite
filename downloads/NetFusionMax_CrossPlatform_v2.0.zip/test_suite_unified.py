"""
Comprehensive Automated Test Suite for NetFusion Max (Unified Engine)
Tests all 12 core modules:
  1. Unit formatting (bytes and speeds)
  2. Engine initialization & default configurations
  3. Network interface discovery & IPv4 validation
  4. Per-interface quota management (Cap & FUP limits)
  5. Boost Mode channel bonding & round-robin routing
  6. Control Mode policy-based traffic steering
  7. Automatic failover when an interface drops
  8. Local dispatch proxy binding and HTTP CONNECT relay
  9. Kernel process suspend / resume simulation
  10. Cross-platform system proxy controller
  11. Atomic data and settings persistence
  12. Midnight rollover & state reset
"""

import sys
import os
import unittest
import socket
import json
import time

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from netfusion_max_engine import (
    NetFusionMaxEngine,
    set_system_proxy,
    format_bytes,
    format_speed,
    DEFAULT_SETTINGS
)


class TestNetFusionMaxUnified(unittest.TestCase):

    def setUp(self):
        self.engine = NetFusionMaxEngine(host="127.0.0.1", port=9999)

    def tearDown(self):
        self.engine.stop()

    # 1. Unit Formatting Tests
    def test_format_bytes(self):
        self.assertEqual(format_bytes(500), "500 B")
        self.assertEqual(format_bytes(2048), "2.0 KB")
        self.assertEqual(format_bytes(5 * 1024 * 1024), "5.0 MB")
        self.assertEqual(format_bytes(25 * 1024 * 1024 * 1024), "25.00 GB")

    def test_format_speed(self):
        self.assertEqual(format_speed(300), "300 B/s")
        self.assertEqual(format_speed(4096), "4.0 KB/s")
        self.assertEqual(format_speed(12 * 1024 * 1024), "12.00 MB/s")

    # 2. Engine Initialization & Defaults
    def test_engine_initialization(self):
        self.assertEqual(self.engine.host, "127.0.0.1")
        self.assertEqual(self.engine.port, 9999)
        self.assertIn(self.engine.mode, ["BOOST", "CONTROL"])
        self.assertIsInstance(self.engine.settings, dict)
        self.assertIsInstance(self.engine.data, dict)

    # 3. Interface Discovery
    def test_get_available_interfaces(self):
        ifaces = self.engine.get_available_interfaces()
        self.assertIsInstance(ifaces, list)
        for ifc in ifaces:
            self.assertIn("name", ifc)
            self.assertIn("ip", ifc)
            self.assertFalse(ifc["ip"].startswith("127."))
            self.assertFalse(ifc["ip"].startswith("169.254."))

    # 4. Per-Interface Quota Management
    def test_per_interface_quotas(self):
        # Default quota
        cap, fup = self.engine.get_interface_quota("NonExistentNIC")
        self.assertEqual(cap, 28.0)
        self.assertEqual(fup, 20.0)

        # Set custom quota for specific Wi-Fi adapter
        self.engine.set_interface_quota("Wi-Fi 2", 15.0, 10.0)
        c2, f2 = self.engine.get_interface_quota("Wi-Fi 2")
        self.assertEqual(c2, 15.0)
        self.assertEqual(f2, 10.0)

    # 5. Boost Mode Channel Bonding (Round-Robin)
    def test_boost_mode_round_robin(self):
        self.engine.mode = "BOOST"
        self.engine.primary_ip = "192.168.1.100"
        self.engine.secondary_ip = "192.168.2.200"
        self.engine.interface_health = {
            "192.168.1.100": {"latency_ms": 12, "alive": True},
            "192.168.2.200": {"latency_ms": 18, "alive": True}
        }

        # Sequence of outgoing interface selections should alternate (round-robin)
        res1 = self.engine._select_outgoing_interface("example.com", 80)
        res2 = self.engine._select_outgoing_interface("example.com", 80)
        res3 = self.engine._select_outgoing_interface("example.com", 80)

        self.assertIn(res1, ["192.168.1.100", "192.168.2.200"])
        self.assertIn(res2, ["192.168.1.100", "192.168.2.200"])
        self.assertNotEqual(res1, res2)  # Alternating
        self.assertEqual(res1, res3)

    # 6. Control Mode Policy Steering
    def test_control_mode_policy_steering(self):
        self.engine.mode = "CONTROL"
        self.engine.primary_ip = "192.168.1.100"       # Bulk downloads & web
        self.engine.secondary_ip = "192.168.2.200"     # Low latency gaming/voice
        self.engine.interface_health = {
            "192.168.1.100": {"latency_ms": 25, "alive": True},
            "192.168.2.200": {"latency_ms": 10, "alive": True}
        }

        # Standard Web (port 80) -> Primary Link
        web_choice = self.engine._select_outgoing_interface("cdn.steam.com", 80)
        self.assertEqual(web_choice, "192.168.1.100")

        # Low-Latency Gaming/Voice (e.g. port 27015 or 50000) -> Secondary Link
        game_choice = self.engine._select_outgoing_interface("voice.discord.gg", 50000)
        self.assertEqual(game_choice, "192.168.2.200")

    # 7. Automatic Failover Logic
    def test_automatic_failover(self):
        self.engine.mode = "BOOST"
        self.engine.primary_ip = "192.168.1.100"
        self.engine.secondary_ip = "192.168.2.200"

        # Simulate primary Wi-Fi dropping offline
        self.engine.interface_health = {
            "192.168.1.100": {"latency_ms": 999, "alive": False},
            "192.168.2.200": {"latency_ms": 15, "alive": True}
        }

        # All traffic must failover automatically to secondary
        choice1 = self.engine._select_outgoing_interface("example.com", 80)
        choice2 = self.engine._select_outgoing_interface("example.com", 443)
        self.assertEqual(choice1, "192.168.2.200")
        self.assertEqual(choice2, "192.168.2.200")

    # 8. Local Dispatch Proxy Socket
    def test_proxy_server_binding(self):
        test_port = 18889
        test_engine = NetFusionMaxEngine(host="127.0.0.1", port=test_port)
        test_engine.start()
        time.sleep(0.5)

        # Attempt TCP connection to local proxy port
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(2.0)
        connected = False
        try:
            s.connect(("127.0.0.1", test_port))
            connected = True
        finally:
            s.close()
            test_engine.stop()

        self.assertTrue(connected)

    # 9. App Network Wi-Fi Blocking & Restoring
    def test_process_suspend_resume_logic(self):
        # Target dummy app
        dummy_app = "test_hog_app.exe"
        self.assertFalse(dummy_app in self.engine.blocked_apps)

        # Cut Wi-Fi on app
        is_blocked, _ = self.engine.toggle_app_network(dummy_app)
        self.assertTrue(is_blocked)
        self.assertIn(dummy_app, self.engine.blocked_apps)

        # Restore Wi-Fi on app
        is_blocked2, _ = self.engine.toggle_app_network(dummy_app)
        self.assertFalse(is_blocked2)
        self.assertNotIn(dummy_app, self.engine.blocked_apps)

        # Test block heavy apps & unblock all
        self.engine.block_heavy_apps_network()
        self.assertTrue(len(self.engine.blocked_apps) > 0)
        self.engine.unblock_all_apps_network()
        self.assertEqual(len(self.engine.blocked_apps), 0)

    # 10. Cross-Platform System Proxy Controller
    def test_system_proxy_controller(self):
        # Enable and Disable test
        res_enable = set_system_proxy(enable=True, proxy_server="127.0.0.1:8888")
        self.assertIsInstance(res_enable, bool)

        res_disable = set_system_proxy(enable=False, proxy_server="127.0.0.1:8888")
        self.assertIsInstance(res_disable, bool)

    # 11. Atomic Persistence
    def test_atomic_persistence(self):
        self.engine.data["test_key"] = "verified_atomic_write"
        self.engine.save_data()

        # Check that data was saved properly
        from netfusion_max_engine import DATA_FILE
        self.assertTrue(os.path.exists(DATA_FILE))
        with open(DATA_FILE, "r", encoding="utf-8") as f:
            d = json.load(f)
            self.assertEqual(d.get("test_key"), "verified_atomic_write")

    # 12. Midnight Rollover Logic
    def test_midnight_rollover_reset(self):
        # Simulate yesterday's date
        self.engine.data["date"] = "2020-01-01"
        self.engine.data["interfaces"] = {"Wi-Fi": {"rx": 1000000, "tx": 500000}}
        self.engine.data["app_usage"] = {"steam.exe": 500000}

        # Trigger monitor tick logic
        import datetime
        today = datetime.date.today().isoformat()
        if self.engine.data.get("date") != today:
            self.engine.data["date"] = today
            self.engine.data["interfaces"] = {}
            self.engine.data["app_usage"] = {}

        self.assertEqual(self.engine.data["date"], today)
        self.assertEqual(len(self.engine.data["interfaces"]), 0)
        self.assertEqual(len(self.engine.data["app_usage"]), 0)


if __name__ == "__main__":
    unittest.main()
