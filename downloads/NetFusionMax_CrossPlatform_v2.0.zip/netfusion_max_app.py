"""
NetFusion Max GUI Application
Unified Bandwidth Guardian & Multi-Wi-Fi Aggregator.
Combines:
  - Per-interface real-time bandwidth & FUP quota tracking with dual progress bars.
  - Multi-Wi-Fi socket bonding (Boost Mode) & policy routing (Control Mode).
  - Per-app network audit and kernel-level process freezing (suspend/resume).
  - 1-Click System Proxy integration.
  - In-place zero-flicker UI updates.
"""

import sys
import os
import threading
import time
import customtkinter as ctk
from PIL import Image

from netfusion_max_engine import (
    NetFusionMaxEngine,
    set_system_proxy,
    format_bytes,
    format_speed,
    BASE_DIR
)

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


class NetFusionMaxApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("NetFusion Max - Bandwidth Guardian & Multi-Wi-Fi Aggregator")
        self.geometry("1060x800")
        self.minsize(940, 720)

        # Set Window and Taskbar Icon
        ico_path = os.path.join(BASE_DIR, "net_guardian.ico")
        if os.path.exists(ico_path):
            try:
                self.iconbitmap(ico_path)
            except Exception:
                pass

        # Initialize Core Engine
        self.engine = NetFusionMaxEngine()
        self.engine.start()

        # UI State
        self.system_proxy_enabled = False
        self.nic_cards = {}       # nic_name -> dict of widget references
        self.app_rows = {}        # app_name -> dict of widget references

        # Build UI
        self.setup_ui()

        # Start periodic UI refresh (1 second)
        self.refresh_ui()

    def setup_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        # ------------------ TOP HEADER ------------------
        header_frame = ctk.CTkFrame(self, fg_color="#131722", corner_radius=0, height=72)
        header_frame.grid(row=0, column=0, sticky="ew")
        header_frame.grid_columnconfigure(1, weight=1)

        # Left: App Logo & Subtitle
        title_box = ctk.CTkFrame(header_frame, fg_color="transparent")
        title_box.grid(row=0, column=0, padx=18, pady=12, sticky="w")

        title_lbl = ctk.CTkLabel(
            title_box,
            text="⚡ NetFusion Max",
            font=ctk.CTkFont(family="Segoe UI", size=20, weight="bold"),
            text_color="#00ffcc"
        )
        title_lbl.pack(anchor="w")

        sub_lbl = ctk.CTkLabel(
            title_box,
            text="Bandwidth Guardian & Multi-Wi-Fi Aggregator",
            font=ctk.CTkFont(size=11),
            text_color="#718096"
        )
        sub_lbl.pack(anchor="w")

        # Center: Combined Live Speed & Global Status
        center_box = ctk.CTkFrame(header_frame, fg_color="transparent")
        center_box.grid(row=0, column=1, padx=12, pady=12)

        self.combined_speed_lbl = ctk.CTkLabel(
            center_box,
            text="▼ 0.0 KB/s  ▲ 0.0 KB/s",
            font=ctk.CTkFont(family="Consolas", size=14, weight="bold"),
            text_color="#00d2ff"
        )
        self.combined_speed_lbl.pack()

        self.global_status_badge = ctk.CTkLabel(
            center_box,
            text="NORMAL SPEED",
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#1e3a2f",
            text_color="#00ff88",
            corner_radius=6,
            padx=10,
            pady=2
        )
        self.global_status_badge.pack(pady=(2, 0))

        # Right: 1-Click System Proxy Toggle
        right_box = ctk.CTkFrame(header_frame, fg_color="transparent")
        right_box.grid(row=0, column=2, padx=18, pady=12, sticky="e")

        self.proxy_switch_var = ctk.BooleanVar(value=False)
        self.proxy_switch = ctk.CTkSwitch(
            right_box,
            text="Multi-Wi-Fi System Proxy",
            font=ctk.CTkFont(size=12, weight="bold"),
            variable=self.proxy_switch_var,
            command=self.toggle_system_proxy,
            progress_color="#00d2ff"
        )
        self.proxy_switch.pack()

        self.proxy_status_lbl = ctk.CTkLabel(
            right_box,
            text="Disabled (Direct Link)",
            font=ctk.CTkFont(size=11),
            text_color="#a0aec0"
        )
        self.proxy_status_lbl.pack(pady=(2, 0))

        # ------------------ MAIN TABVIEW ------------------
        self.tabview = ctk.CTkTabview(self, fg_color="#181c27", segmented_button_fg_color="#131722",
                                      segmented_button_selected_color="#008080",
                                      segmented_button_selected_hover_color="#00a8a8")
        self.tabview.grid(row=1, column=0, padx=16, pady=(10, 16), sticky="nsew")

        # Tabs
        self.tab_monitor = self.tabview.add("📡 Multi-Wi-Fi & FUP Monitor")
        self.tab_bonding = self.tabview.add("🚀 Channel Bonding & Control")
        self.tab_apps = self.tabview.add("📊 Per-App Audit & Auto-Pause")
        self.tab_settings = self.tabview.add("⚙️ Quotas & Settings")

        self.setup_tab_monitor()
        self.setup_tab_bonding()
        self.setup_tab_apps()
        self.setup_tab_settings()

    # ==========================================================
    # TAB 1: Multi-Wi-Fi & FUP Monitor
    # ==========================================================
    def setup_tab_monitor(self):
        self.tab_monitor.grid_columnconfigure(0, weight=1)
        self.tab_monitor.grid_rowconfigure(1, weight=1)

        # Top Combined Banner
        summary_card = ctk.CTkFrame(self.tab_monitor, fg_color="#1f2433", corner_radius=8)
        summary_card.grid(row=0, column=0, padx=12, pady=8, sticky="ew")
        summary_card.grid_columnconfigure((0, 1, 2, 3), weight=1)

        # Metric 1: Total Today Usage
        m1 = ctk.CTkFrame(summary_card, fg_color="transparent")
        m1.grid(row=0, column=0, padx=12, pady=10)
        ctk.CTkLabel(m1, text="TOTAL DATA TODAY", font=ctk.CTkFont(size=11, weight="bold"), text_color="#718096").pack()
        self.total_usage_lbl = ctk.CTkLabel(m1, text="0.00 GB", font=ctk.CTkFont(size=18, weight="bold"), text_color="#ffffff")
        self.total_usage_lbl.pack()

        # Metric 2: Active Links
        m2 = ctk.CTkFrame(summary_card, fg_color="transparent")
        m2.grid(row=0, column=1, padx=12, pady=10)
        ctk.CTkLabel(m2, text="ACTIVE WI-FI / LINKS", font=ctk.CTkFont(size=11, weight="bold"), text_color="#718096").pack()
        self.active_links_lbl = ctk.CTkLabel(m2, text="1 Active", font=ctk.CTkFont(size=18, weight="bold"), text_color="#00ffcc")
        self.active_links_lbl.pack()

        # Metric 3: Bonding State
        m3 = ctk.CTkFrame(summary_card, fg_color="transparent")
        m3.grid(row=0, column=2, padx=12, pady=10)
        ctk.CTkLabel(m3, text="OPERATIONAL MODE", font=ctk.CTkFont(size=11, weight="bold"), text_color="#718096").pack()
        self.mode_status_lbl = ctk.CTkLabel(m3, text="⚡ BOOST BONDING", font=ctk.CTkFont(size=16, weight="bold"), text_color="#ffbe0b")
        self.mode_status_lbl.pack()

        # Metric 4: Auto-Pause State
        m4 = ctk.CTkFrame(summary_card, fg_color="transparent")
        m4.grid(row=0, column=3, padx=12, pady=10)
        ctk.CTkLabel(m4, text="FUP DEFENSE SHIELD", font=ctk.CTkFont(size=11, weight="bold"), text_color="#718096").pack()
        self.shield_status_lbl = ctk.CTkLabel(m4, text="🛡️ ARMED & ACTIVE", font=ctk.CTkFont(size=16, weight="bold"), text_color="#00ff88")
        self.shield_status_lbl.pack()

        # Scrollable container for per-interface cards
        self.interfaces_scroll = ctk.CTkScrollableFrame(self.tab_monitor, fg_color="transparent")
        self.interfaces_scroll.grid(row=1, column=0, padx=12, pady=(4, 12), sticky="nsew")
        self.interfaces_scroll.grid_columnconfigure(0, weight=1)

    def _get_or_create_nic_card(self, nic_name, ip_address):
        """Creates or retrieves a zero-flicker UI card for an individual network interface."""
        if nic_name in self.nic_cards:
            return self.nic_cards[nic_name]

        card = ctk.CTkFrame(self.interfaces_scroll, fg_color="#1e2332", corner_radius=8, border_width=1, border_color="#2d3748")
        card.pack(fill="x", pady=6, padx=4)
        card.grid_columnconfigure((0, 1), weight=1)

        # Card Header: Interface Name, IP, Live Speed, Latency
        top_row = ctk.CTkFrame(card, fg_color="transparent")
        top_row.grid(row=0, column=0, columnspan=2, padx=14, pady=(10, 4), sticky="ew")
        top_row.grid_columnconfigure(1, weight=1)

        name_lbl = ctk.CTkLabel(top_row, text=f"📶 {nic_name}", font=ctk.CTkFont(size=15, weight="bold"), text_color="#00d2ff")
        name_lbl.grid(row=0, column=0, sticky="w")

        ip_lbl = ctk.CTkLabel(top_row, text=f"IP: {ip_address}", font=ctk.CTkFont(size=11), text_color="#a0aec0")
        ip_lbl.grid(row=0, column=1, padx=12, sticky="w")

        speed_lbl = ctk.CTkLabel(top_row, text="▼ 0.0 KB/s  ▲ 0.0 KB/s", font=ctk.CTkFont(family="Consolas", size=12, weight="bold"), text_color="#00ffcc")
        speed_lbl.grid(row=0, column=2, padx=10, sticky="e")

        health_badge = ctk.CTkLabel(top_row, text="15ms (Healthy)", font=ctk.CTkFont(size=10, weight="bold"), fg_color="#1e3a2f", text_color="#00ff88", corner_radius=4, padx=6, pady=1)
        health_badge.grid(row=0, column=3, sticky="e")

        # Left Column: Dual Progress Bars (Cap + FUP)
        bars_col = ctk.CTkFrame(card, fg_color="transparent")
        bars_col.grid(row=1, column=0, padx=14, pady=8, sticky="nsew")

        # Daily Cap Progress Bar
        cap_title_lbl = ctk.CTkLabel(bars_col, text="Daily Data Cap", font=ctk.CTkFont(size=12, weight="bold"))
        cap_title_lbl.pack(anchor="w")

        cap_bar = ctk.CTkProgressBar(bars_col, height=12, corner_radius=6, progress_color="#00d2ff", fg_color="#2b2d42")
        cap_bar.pack(fill="x", pady=(2, 2))
        cap_bar.set(0)

        cap_detail_lbl = ctk.CTkLabel(bars_col, text="0.00 GB / 28.00 GB", font=ctk.CTkFont(size=10), text_color="#a0aec0")
        cap_detail_lbl.pack(anchor="w", pady=(0, 6))

        # FUP Slowdown Progress Bar
        fup_title_lbl = ctk.CTkLabel(bars_col, text="FUP Slowdown Zone", font=ctk.CTkFont(size=12, weight="bold"))
        fup_title_lbl.pack(anchor="w")

        fup_bar = ctk.CTkProgressBar(bars_col, height=12, corner_radius=6, progress_color="#ffbe0b", fg_color="#2b2d42")
        fup_bar.pack(fill="x", pady=(2, 2))
        fup_bar.set(0)

        fup_detail_lbl = ctk.CTkLabel(bars_col, text="0.00 GB / 20.00 GB to FUP", font=ctk.CTkFont(size=10), text_color="#a0aec0")
        fup_detail_lbl.pack(anchor="w")

        # Right Column: Individual Quota Controls
        controls_col = ctk.CTkFrame(card, fg_color="transparent")
        controls_col.grid(row=1, column=1, padx=14, pady=8, sticky="nsew")

        cap_val, fup_val = self.engine.get_interface_quota(nic_name)

        q_row1 = ctk.CTkFrame(controls_col, fg_color="transparent")
        q_row1.pack(fill="x", pady=2)
        ctk.CTkLabel(q_row1, text="Cap (GB):", font=ctk.CTkFont(size=11)).pack(side="left", padx=(0, 4))
        cap_entry = ctk.CTkEntry(q_row1, width=65, height=26, font=ctk.CTkFont(size=11))
        cap_entry.insert(0, str(cap_val))
        cap_entry.pack(side="left", padx=2)

        ctk.CTkLabel(q_row1, text="FUP (GB):", font=ctk.CTkFont(size=11)).pack(side="left", padx=(10, 4))
        fup_entry = ctk.CTkEntry(q_row1, width=65, height=26, font=ctk.CTkFont(size=11))
        fup_entry.insert(0, str(fup_val))
        fup_entry.pack(side="left", padx=2)

        apply_btn = ctk.CTkButton(
            q_row1,
            text="Save Quota",
            width=75,
            height=26,
            font=ctk.CTkFont(size=11, weight="bold"),
            fg_color="#2b6cb0",
            hover_color="#2c5282",
            command=lambda n=nic_name, ce=cap_entry, fe=fup_entry: self.save_nic_quota(n, ce, fe)
        )
        apply_btn.pack(side="left", padx=8)

        status_lbl = ctk.CTkLabel(controls_col, text="Status: Connected & Guarded", font=ctk.CTkFont(size=11), text_color="#00ff88")
        status_lbl.pack(anchor="w", pady=(8, 0))

        card_ref = {
            "card": card,
            "ip_lbl": ip_lbl,
            "speed_lbl": speed_lbl,
            "health_badge": health_badge,
            "cap_title_lbl": cap_title_lbl,
            "cap_bar": cap_bar,
            "cap_detail_lbl": cap_detail_lbl,
            "fup_title_lbl": fup_title_lbl,
            "fup_bar": fup_bar,
            "fup_detail_lbl": fup_detail_lbl,
            "status_lbl": status_lbl,
            "cap_entry": cap_entry,
            "fup_entry": fup_entry
        }
        self.nic_cards[nic_name] = card_ref
        return card_ref

    def save_nic_quota(self, nic_name, cap_entry, fup_entry):
        try:
            c = float(cap_entry.get())
            f = float(fup_entry.get())
            self.engine.set_interface_quota(nic_name, c, f)
            if nic_name in self.nic_cards:
                self.nic_cards[nic_name]["status_lbl"].configure(text="Quota Saved Successfully!", text_color="#00ff88")
        except ValueError:
            if nic_name in self.nic_cards:
                self.nic_cards[nic_name]["status_lbl"].configure(text="Invalid numbers entered!", text_color="#ff4d4d")

    # ==========================================================
    # TAB 2: Channel Bonding & Traffic Steering
    # ==========================================================
    def setup_tab_bonding(self):
        self.tab_bonding.grid_columnconfigure(0, weight=1)

        # Mode Selection Card
        mode_card = ctk.CTkFrame(self.tab_bonding, fg_color="#1e2332", corner_radius=8)
        mode_card.pack(fill="x", padx=16, pady=10)

        ctk.CTkLabel(mode_card, text="Operational Bonding Mode", font=ctk.CTkFont(size=15, weight="bold"), text_color="#00ffcc").pack(anchor="w", padx=16, pady=(12, 6))

        self.mode_var = ctk.StringVar(value=self.engine.mode)

        boost_rb = ctk.CTkRadioButton(
            mode_card,
            text="⚡ Boost Mode (Channel Bonding & Automatic Failover)\nCombines all detected Wi-Fi adapters round-robin to maximize download speed.",
            variable=self.mode_var,
            value="BOOST",
            command=self.on_mode_change,
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ffffff"
        )
        boost_rb.pack(anchor="w", padx=24, pady=6)

        control_rb = ctk.CTkRadioButton(
            mode_card,
            text="🎛️ Control Mode (Granular Traffic Steering)\nSteers downloads and web surfing to Wi-Fi 1, while dedicating Wi-Fi 2 exclusively to Discord/Zoom/Gaming.",
            variable=self.mode_var,
            value="CONTROL",
            command=self.on_mode_change,
            font=ctk.CTkFont(size=12, weight="bold"),
            text_color="#ffffff"
        )
        control_rb.pack(anchor="w", padx=24, pady=(6, 14))

        # Interface Assignment Card
        assign_card = ctk.CTkFrame(self.tab_bonding, fg_color="#1e2332", corner_radius=8)
        assign_card.pack(fill="x", padx=16, pady=10)

        ctk.CTkLabel(assign_card, text="Interface Allocation & Latency Watchdog", font=ctk.CTkFont(size=15, weight="bold"), text_color="#00d2ff").pack(anchor="w", padx=16, pady=(12, 8))

        row = ctk.CTkFrame(assign_card, fg_color="transparent")
        row.pack(fill="x", padx=16, pady=6)
        row.grid_columnconfigure((0, 1), weight=1)

        # Primary Link
        p_frame = ctk.CTkFrame(row, fg_color="#131722", corner_radius=6)
        p_frame.grid(row=0, column=0, padx=6, pady=6, sticky="ew")
        ctk.CTkLabel(p_frame, text="Primary Wi-Fi Link (Bulk Traffic)", font=ctk.CTkFont(size=12, weight="bold")).pack(padx=10, pady=(8, 2), anchor="w")
        self.p_ip_lbl = ctk.CTkLabel(p_frame, text="IP: Detecting...", font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.p_ip_lbl.pack(padx=10, pady=2, anchor="w")
        self.p_ping_lbl = ctk.CTkLabel(p_frame, text="Health: 15ms (Online)", font=ctk.CTkFont(size=11), text_color="#00ff88")
        self.p_ping_lbl.pack(padx=10, pady=(2, 8), anchor="w")

        # Secondary Link
        s_frame = ctk.CTkFrame(row, fg_color="#131722", corner_radius=6)
        s_frame.grid(row=0, column=1, padx=6, pady=6, sticky="ew")
        ctk.CTkLabel(s_frame, text="Secondary Wi-Fi / Tether (Low Latency)", font=ctk.CTkFont(size=12, weight="bold")).pack(padx=10, pady=(8, 2), anchor="w")
        self.s_ip_lbl = ctk.CTkLabel(s_frame, text="IP: Plug in Phone USB / Dongle to Bond", font=ctk.CTkFont(size=11), text_color="#ffd166")
        self.s_ip_lbl.pack(padx=10, pady=2, anchor="w")
        self.s_ping_lbl = ctk.CTkLabel(s_frame, text="Health: Standby", font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.s_ping_lbl.pack(padx=10, pady=(2, 8), anchor="w")

        # Proxy Info Banner
        info_card = ctk.CTkFrame(self.tab_bonding, fg_color="#182338", corner_radius=8)
        info_card.pack(fill="x", padx=16, pady=10)

        ctk.CTkLabel(
            info_card,
            text="Local Dispatch Proxy: 127.0.0.1:8888 • Real-time socket relay with TCP_NODELAY and 64KB buffers.\nTurn on the 'Multi-Wi-Fi System Proxy' switch in the top header to route your entire OS through the bonded link.",
            font=ctk.CTkFont(size=11),
            text_color="#cbd5e0",
            justify="left"
        ).pack(padx=14, pady=10, anchor="w")

    def on_mode_change(self):
        new_mode = self.mode_var.get()
        self.engine.mode = new_mode
        self.engine.settings["operational_mode"] = new_mode
        self.engine.save_settings()

    # ==========================================================
    # TAB 3: Per-App Audit & Auto-Pause
    # ==========================================================
    def setup_tab_apps(self):
        self.tab_apps.grid_columnconfigure(0, weight=1)
        self.tab_apps.grid_rowconfigure(1, weight=1)

        # Action Toolbar
        toolbar = ctk.CTkFrame(self.tab_apps, fg_color="#1e2332", corner_radius=8)
        toolbar.grid(row=0, column=0, padx=12, pady=8, sticky="ew")
        toolbar.grid_columnconfigure(1, weight=1)

        self.auto_pause_var = ctk.BooleanVar(value=self.engine.settings.get("auto_pause_fup", True))
        self.auto_pause_chk = ctk.CTkCheckBox(
            toolbar,
            text="Auto-Pause Heavy Downloaders at FUP Limit",
            variable=self.auto_pause_var,
            command=self.toggle_auto_pause,
            font=ctk.CTkFont(size=12, weight="bold")
        )
        self.auto_pause_chk.grid(row=0, column=0, padx=14, pady=10, sticky="w")

        btn_box = ctk.CTkFrame(toolbar, fg_color="transparent")
        btn_box.grid(row=0, column=2, padx=14, pady=10, sticky="e")

        pause_all_btn = ctk.CTkButton(
            btn_box,
            text="⏸ Pause Heavy Hogs",
            width=140,
            height=30,
            fg_color="#c53030",
            hover_color="#9b2c2c",
            command=self.action_pause_heavy
        )
        pause_all_btn.pack(side="left", padx=4)

        resume_all_btn = ctk.CTkButton(
            btn_box,
            text="▶ Resume All Apps",
            width=140,
            height=30,
            fg_color="#2f855a",
            hover_color="#276749",
            command=self.action_resume_all
        )
        resume_all_btn.pack(side="left", padx=4)

        # Scrollable App Table
        self.apps_scroll = ctk.CTkScrollableFrame(self.tab_apps, fg_color="#181c27")
        self.apps_scroll.grid(row=1, column=0, padx=12, pady=(0, 12), sticky="nsew")
        self.apps_scroll.grid_columnconfigure(0, weight=3)  # Name
        self.apps_scroll.grid_columnconfigure(1, weight=1)  # MB
        self.apps_scroll.grid_columnconfigure(2, weight=1)  # Interface
        self.apps_scroll.grid_columnconfigure(3, weight=1)  # Status
        self.apps_scroll.grid_columnconfigure(4, weight=1)  # Action

        # Table Header
        h_frame = ctk.CTkFrame(self.apps_scroll, fg_color="#131722", height=32, corner_radius=4)
        h_frame.grid(row=0, column=0, columnspan=5, sticky="ew", pady=(0, 4))
        h_frame.grid_columnconfigure(0, weight=3)
        h_frame.grid_columnconfigure(1, weight=1)
        h_frame.grid_columnconfigure(2, weight=1)
        h_frame.grid_columnconfigure(3, weight=1)
        h_frame.grid_columnconfigure(4, weight=1)

        ctk.CTkLabel(h_frame, text="APPLICATION", font=ctk.CTkFont(size=11, weight="bold"), text_color="#a0aec0").grid(row=0, column=0, padx=10, sticky="w")
        ctk.CTkLabel(h_frame, text="DATA SPENT TODAY", font=ctk.CTkFont(size=11, weight="bold"), text_color="#a0aec0").grid(row=0, column=1, padx=6, sticky="w")
        ctk.CTkLabel(h_frame, text="WI-FI LINK", font=ctk.CTkFont(size=11, weight="bold"), text_color="#a0aec0").grid(row=0, column=2, padx=6, sticky="w")
        ctk.CTkLabel(h_frame, text="STATUS", font=ctk.CTkFont(size=11, weight="bold"), text_color="#a0aec0").grid(row=0, column=3, padx=6, sticky="w")
        ctk.CTkLabel(h_frame, text="ACTION", font=ctk.CTkFont(size=11, weight="bold"), text_color="#a0aec0").grid(row=0, column=4, padx=10, sticky="e")

    def toggle_auto_pause(self):
        val = self.auto_pause_var.get()
        self.engine.settings["auto_pause_fup"] = val
        self.engine.settings["auto_pause_cap"] = val
        self.engine.save_settings()

    def action_pause_heavy(self):
        cnt = self.engine.pause_heavy_apps()
        self.update_apps_table()

    def action_resume_all(self):
        cnt = self.engine.resume_all_apps()
        self.update_apps_table()

    # ==========================================================
    # TAB 4: Settings & About
    # ==========================================================
    def setup_tab_settings(self):
        self.tab_settings.grid_columnconfigure(0, weight=1)

        card = ctk.CTkFrame(self.tab_settings, fg_color="#1e2332", corner_radius=8)
        card.pack(fill="x", padx=16, pady=12)

        ctk.CTkLabel(card, text="Default Quota Policy", font=ctk.CTkFont(size=15, weight="bold"), text_color="#00ffcc").pack(anchor="w", padx=16, pady=(12, 6))

        row1 = ctk.CTkFrame(card, fg_color="transparent")
        row1.pack(fill="x", padx=16, pady=4)

        ctk.CTkLabel(row1, text="Default Daily Cap (GB):", font=ctk.CTkFont(size=12)).pack(side="left", padx=(0, 6))
        self.default_cap_entry = ctk.CTkEntry(row1, width=70, height=28)
        self.default_cap_entry.insert(0, str(self.engine.settings.get("interface_quotas", {}).get("default", {}).get("daily_cap_gb", 28.0)))
        self.default_cap_entry.pack(side="left", padx=4)

        ctk.CTkLabel(row1, text="Default FUP Warn (GB):", font=ctk.CTkFont(size=12)).pack(side="left", padx=(16, 6))
        self.default_fup_entry = ctk.CTkEntry(row1, width=70, height=28)
        self.default_fup_entry.insert(0, str(self.engine.settings.get("interface_quotas", {}).get("default", {}).get("warning_fup_gb", 20.0)))
        self.default_fup_entry.pack(side="left", padx=4)

        save_default_btn = ctk.CTkButton(
            row1,
            text="Save Default",
            width=90,
            height=28,
            command=self.save_default_quotas,
            fg_color="#2b6cb0",
            hover_color="#2c5282"
        )
        save_default_btn.pack(side="left", padx=12)

        # Security Card
        sec_card = ctk.CTkFrame(self.tab_settings, fg_color="#1e2332", corner_radius=8)
        sec_card.pack(fill="x", padx=16, pady=12)

        ctk.CTkLabel(sec_card, text="Security & Privacy Guarantee", font=ctk.CTkFont(size=15, weight="bold"), text_color="#00d2ff").pack(anchor="w", padx=16, pady=(12, 4))
        ctk.CTkLabel(
            sec_card,
            text="• 100% Offline-First: All routing and tracking occurs exclusively on 127.0.0.1.\n• Zero Cloud Telemetry: No external tracking, telemetry, or server communication.\n• Safe Kernel Freezing: Processes are suspended via Windows kernel API without data corruption.\n• Atomic Persistence: Data files are protected via write-and-rename atomic transactions.",
            font=ctk.CTkFont(size=11),
            text_color="#cbd5e0",
            justify="left"
        ).pack(anchor="w", padx=16, pady=(4, 12))

    def save_default_quotas(self):
        try:
            c = float(self.default_cap_entry.get())
            f = float(self.default_fup_entry.get())
            self.engine.set_interface_quota("default", c, f)
        except ValueError:
            pass

    # ==========================================================
    # Periodic UI Refresh Loop (1 second)
    # ==========================================================
    def refresh_ui(self):
        try:
            # 1. Calculate Combined Metrics across all interfaces
            interfaces_data = self.engine.data.get("interfaces", {})
            total_rx = sum(d.get("rx", 0.0) for d in interfaces_data.values())
            total_tx = sum(d.get("tx", 0.0) for d in interfaces_data.values())
            total_bytes = total_rx + total_tx

            total_rx_speed = sum(s.get("rx_speed", 0.0) for s in self.engine.nic_speeds.values())
            total_tx_speed = sum(s.get("tx_speed", 0.0) for s in self.engine.nic_speeds.values())

            # Top Header Updates
            self.combined_speed_lbl.configure(text=f"▼ {format_speed(total_rx_speed)}  ▲ {format_speed(total_tx_speed)}")
            self.total_usage_lbl.configure(text=format_bytes(total_bytes))

            # Active Interfaces Count
            active_ifaces = self.engine.get_available_interfaces()
            link_cnt = len(active_ifaces)
            self.active_links_lbl.configure(text=f"{link_cnt} Active Link{'s' if link_cnt != 1 else ''}")

            # Mode & Shield
            mode_text = "⚡ BOOST BONDING" if self.engine.mode == "BOOST" else "🎛️ CONTROL STEERING"
            self.mode_status_lbl.configure(text=mode_text)

            # Global Status Badge
            any_fup = any(self.engine.data.get("notified_fup", {}).values())
            any_cap = any(self.engine.data.get("notified_cap", {}).values())

            if any_cap:
                self.global_status_badge.configure(text="CAP EXCEEDED", fg_color="#4a151b", text_color="#ff4d4d")
            elif any_fup:
                self.global_status_badge.configure(text="FUP SLOWDOWN ZONE", fg_color="#4a3a10", text_color="#ffbe0b")
            elif self.system_proxy_enabled:
                self.global_status_badge.configure(text="BONDING PROXY ACTIVE", fg_color="#183b4e", text_color="#00d2ff")
            else:
                self.global_status_badge.configure(text="NORMAL SPEED", fg_color="#1e3a2f", text_color="#00ff88")

            # 2. Update / Create Per-Interface Cards
            for ifc in active_ifaces:
                nic_name = ifc["name"]
                ip_addr = ifc["ip"]
                card_ref = self._get_or_create_nic_card(nic_name, ip_addr)

                # Speeds
                speeds = self.engine.nic_speeds.get(nic_name, {"rx_speed": 0.0, "tx_speed": 0.0})
                card_ref["speed_lbl"].configure(
                    text=f"▼ {format_speed(speeds['rx_speed'])}  ▲ {format_speed(speeds['tx_speed'])}"
                )

                # Health / Latency
                health = self.engine.interface_health.get(ip_addr, {"latency_ms": 15, "alive": True})
                if health.get("alive"):
                    card_ref["health_badge"].configure(text=f"{health.get('latency_ms', 15)}ms (Healthy)", fg_color="#1e3a2f", text_color="#00ff88")
                else:
                    card_ref["health_badge"].configure(text="Offline / Failover", fg_color="#4a151b", text_color="#ff4d4d")

                # Usage & Quota Progress Bars
                nic_info = interfaces_data.get(nic_name, {"rx": 0.0, "tx": 0.0})
                nic_bytes = nic_info.get("rx", 0.0) + nic_info.get("tx", 0.0)
                nic_gb = nic_bytes / (1024**3)

                cap_limit, fup_limit = self.engine.get_interface_quota(nic_name)

                # Daily Cap Bar
                cap_frac = min(1.0, nic_gb / cap_limit) if cap_limit > 0 else 0.0
                card_ref["cap_bar"].set(cap_frac)
                rem_cap = max(0.0, cap_limit - nic_gb)
                card_ref["cap_title_lbl"].configure(text=f"Daily Data Cap ({cap_limit:.1f} GB)")
                card_ref["cap_detail_lbl"].configure(
                    text=f"{nic_gb:.2f} GB / {cap_limit:.2f} GB ({cap_frac*100:.1f}%) • {rem_cap:.2f} GB left"
                )

                # FUP Warning Bar
                fup_frac = min(1.0, nic_gb / fup_limit) if fup_limit > 0 else 0.0
                card_ref["fup_bar"].set(fup_frac)
                rem_fup = max(0.0, fup_limit - nic_gb)
                card_ref["fup_title_lbl"].configure(text=f"FUP Slowdown Zone ({fup_limit:.1f} GB)")
                card_ref["fup_detail_lbl"].configure(
                    text=f"{nic_gb:.2f} GB / {fup_limit:.2f} GB ({fup_frac*100:.1f}%) • {rem_fup:.2f} GB to slowdown"
                )

                # Status
                if nic_gb >= cap_limit:
                    card_ref["status_lbl"].configure(text="Status: Cap Exceeded!", text_color="#ff4d4d")
                elif nic_gb >= fup_limit:
                    card_ref["status_lbl"].configure(text="Status: In FUP Slowdown Zone", text_color="#ffbe0b")
                else:
                    card_ref["status_lbl"].configure(text="Status: Guarded & Normal Speed", text_color="#00ff88")

            # 3. Update Bonding Tab Labels
            if self.engine.primary_ip:
                self.p_ip_lbl.configure(text=f"IP: {self.engine.primary_ip}")
                h = self.engine.interface_health.get(self.engine.primary_ip, {"latency_ms": 15, "alive": True})
                self.p_ping_lbl.configure(text=f"Health: {h['latency_ms']}ms ({'Online' if h['alive'] else 'Failing'})",
                                          text_color="#00ff88" if h['alive'] else "#ff4d4d")

            if self.engine.secondary_ip:
                self.s_ip_lbl.configure(text=f"IP: {self.engine.secondary_ip}")
                h = self.engine.interface_health.get(self.engine.secondary_ip, {"latency_ms": 20, "alive": True})
                self.s_ping_lbl.configure(text=f"Health: {h['latency_ms']}ms ({'Online' if h['alive'] else 'Failing'})",
                                          text_color="#00ff88" if h['alive'] else "#ff4d4d")
            else:
                self.s_ip_lbl.configure(text="IP: Plug in Phone USB / Dongle to Bond")
                self.s_ping_lbl.configure(text="Health: Standby (1 Link Active)", text_color="#ffd166")

            # 4. Update App Network Table
            self.update_apps_table()

        except Exception as e:
            print("Error during UI refresh:", e)

        # Reschedule next tick (1 second)
        self.after(1000, self.refresh_ui)

    def update_apps_table(self):
        """Zero-flicker in-place widget updates for active applications."""
        app_usage = self.engine.data.get("app_usage", {})
        app_nic = self.engine.data.get("app_nic", {})
        sorted_apps = sorted(app_usage.items(), key=lambda x: x[1], reverse=True)[:30]

        top_names_set = set(name.lower() for name, _ in sorted_apps)

        # Hide apps no longer in top list
        for name, row in list(self.app_rows.items()):
            if name.lower() not in top_names_set:
                row["frame"].grid_remove()

        for idx, (app_name, total_bytes) in enumerate(sorted_apps, start=1):
            is_suspended = any(
                pname.lower() == app_name.lower()
                for pid, pname in self.engine.active_pids_cache.items()
                if pid in self.engine.suspended_pids
            )
            nic_used = app_nic.get(app_name, "Wi-Fi")

            if app_name in self.app_rows:
                # Update in-place
                row = self.app_rows[app_name]
                row["frame"].grid(row=idx, column=0, columnspan=5, sticky="ew", pady=1)
                row["mb_lbl"].configure(text=format_bytes(total_bytes))
                row["nic_lbl"].configure(text=nic_used)

                if is_suspended:
                    row["status_badge"].configure(text="FROZEN", fg_color="#4a151b", text_color="#ff4d4d")
                    row["btn"].configure(text="▶ Resume", fg_color="#2f855a", hover_color="#276749")
                else:
                    row["status_badge"].configure(text="ACTIVE", fg_color="#1e3a2f", text_color="#00ff88")
                    row["btn"].configure(text="⏸ Freeze", fg_color="#c53030", hover_color="#9b2c2c")
            else:
                # Create row once
                row_frame = ctk.CTkFrame(self.apps_scroll, fg_color="#1b202e" if idx % 2 == 0 else "#161a25", height=32, corner_radius=4)
                row_frame.grid(row=idx, column=0, columnspan=5, sticky="ew", pady=1)
                row_frame.grid_columnconfigure(0, weight=3)
                row_frame.grid_columnconfigure(1, weight=1)
                row_frame.grid_columnconfigure(2, weight=1)
                row_frame.grid_columnconfigure(3, weight=1)
                row_frame.grid_columnconfigure(4, weight=1)

                name_lbl = ctk.CTkLabel(row_frame, text=app_name, font=ctk.CTkFont(size=11, weight="bold"), text_color="#ffffff")
                name_lbl.grid(row=0, column=0, padx=10, sticky="w")

                mb_lbl = ctk.CTkLabel(row_frame, text=format_bytes(total_bytes), font=ctk.CTkFont(size=11), text_color="#00ffcc")
                mb_lbl.grid(row=0, column=1, padx=6, sticky="w")

                nic_lbl = ctk.CTkLabel(row_frame, text=nic_used, font=ctk.CTkFont(size=11), text_color="#a0aec0")
                nic_lbl.grid(row=0, column=2, padx=6, sticky="w")

                status_badge = ctk.CTkLabel(
                    row_frame,
                    text="FROZEN" if is_suspended else "ACTIVE",
                    font=ctk.CTkFont(size=10, weight="bold"),
                    fg_color="#4a151b" if is_suspended else "#1e3a2f",
                    text_color="#ff4d4d" if is_suspended else "#00ff88",
                    corner_radius=4,
                    padx=6,
                    pady=1
                )
                status_badge.grid(row=0, column=3, padx=6, sticky="w")

                btn = ctk.CTkButton(
                    row_frame,
                    text="▶ Resume" if is_suspended else "⏸ Freeze",
                    width=75,
                    height=24,
                    font=ctk.CTkFont(size=10, weight="bold"),
                    fg_color="#2f855a" if is_suspended else "#c53030",
                    hover_color="#276749" if is_suspended else "#9b2c2c",
                    command=lambda n=app_name: self.toggle_single_app(n)
                )
                btn.grid(row=0, column=4, padx=10, sticky="e")

                self.app_rows[app_name] = {
                    "frame": row_frame,
                    "mb_lbl": mb_lbl,
                    "nic_lbl": nic_lbl,
                    "status_badge": status_badge,
                    "btn": btn
                }

    def toggle_single_app(self, app_name):
        new_state, count = self.engine.toggle_process_state(app_name)
        self.update_apps_table()

    def toggle_system_proxy(self):
        enabled = self.proxy_switch_var.get()
        proxy_addr = f"127.0.0.1:{self.engine.port}"
        success = set_system_proxy(enable=enabled, proxy_server=proxy_addr)

        if success:
            self.system_proxy_enabled = enabled
            if enabled:
                self.proxy_status_lbl.configure(text=f"Active ({proxy_addr})", text_color="#00ffcc")
            else:
                self.proxy_status_lbl.configure(text="Disabled (Direct Link)", text_color="#a0aec0")
        else:
            self.proxy_switch_var.set(not enabled)
            self.proxy_status_lbl.configure(text="Config Failed (Try Admin)", text_color="#ff4d4d")


if __name__ == "__main__":
    app = NetFusionMaxApp()
    app.mainloop()
