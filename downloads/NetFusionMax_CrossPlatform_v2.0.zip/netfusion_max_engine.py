"""
NetFusion Max Engine (Unified Bandwidth Guardian & Multi-Wi-Fi Aggregator)
Combines:
  1. Per-interface real-time bandwidth & FUP quota tracking.
  2. Multi-Wi-Fi socket bonding (Boost Mode) & policy routing (Control Mode).
  3. Per-app network monitoring and kernel-level process freezing (suspend/resume).
  4. Local dispatch proxy on 127.0.0.1:8888 with automatic failover and system proxy integration.
  5. Midnight rollover and atomic JSON state persistence.
"""

import sys
import os
import socket
import select
import threading
import time
import json
import datetime
import subprocess
import psutil

if sys.platform == "win32":
    try:
        import winreg
    except ImportError:
        winreg = None
else:
    winreg = None

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "netfusion_max_data.json")
SETTINGS_FILE = os.path.join(BASE_DIR, "netfusion_max_settings.json")

DEFAULT_SETTINGS = {
    "proxy_port": 8888,
    "operational_mode": "BOOST",  # "BOOST" or "CONTROL"
    "auto_pause_fup": True,
    "auto_pause_cap": True,
    "heavy_apps": [
        "steam.exe", "steamwebhelper.exe",
        "epicgameslauncher.exe",
        "riotclientux.exe", "riotclientservices.exe", "valorant.exe", "leagueclient.exe",
        "battle.net.exe", "agent.exe",
        "utorrent.exe", "bittorrent.exe", "qbittorrent.exe",
        "idman.exe", "chrome.exe", "msedge.exe", "firefox.exe"
    ],
    "interface_quotas": {
        "default": {"daily_cap_gb": 28.0, "warning_fup_gb": 20.0}
    }
}


def format_bytes(b):
    if b >= 1024**3:
        return f"{b / (1024**3):.2f} GB"
    elif b >= 1024**2:
        return f"{b / (1024**2):.1f} MB"
    elif b >= 1024:
        return f"{b / 1024:.1f} KB"
    else:
        return f"{int(b)} B"


def format_speed(bps):
    if bps >= 1024**2:
        return f"{bps / (1024**2):.2f} MB/s"
    elif bps >= 1024:
        return f"{bps / 1024:.1f} KB/s"
    else:
        return f"{int(bps)} B/s"


# Cross-Platform System Proxy Controller Utility (Windows, macOS, Linux)
def set_system_proxy(enable=True, proxy_server="127.0.0.1:8888"):
    host, port = proxy_server.split(":")

    if sys.platform == "win32" and winreg:
        try:
            import ctypes
            reg_key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                0,
                winreg.KEY_SET_VALUE
            )
            winreg.SetValueEx(reg_key, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
            if enable:
                winreg.SetValueEx(reg_key, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
            winreg.CloseKey(reg_key)

            # Broadcast change to Windows WinINet
            INTERNET_OPTION_SETTINGS_CHANGED = 39
            INTERNET_OPTION_REFRESH = 37
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
            return True
        except Exception as e:
            print("Failed to configure Windows proxy:", e)
            return False

    elif sys.platform == "darwin":
        try:
            state = "on" if enable else "off"
            subprocess.run(["networksetup", "-setwebproxystate", "Wi-Fi", state], check=False)
            subprocess.run(["networksetup", "-setsecurewebproxystate", "Wi-Fi", state], check=False)
            if enable:
                subprocess.run(["networksetup", "-setwebproxy", "Wi-Fi", host, port], check=False)
                subprocess.run(["networksetup", "-setsecurewebproxy", "Wi-Fi", host, port], check=False)
            return True
        except Exception as e:
            print("Failed to configure macOS proxy:", e)
            return False

    elif sys.platform.startswith("linux"):
        try:
            if enable:
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy", "mode", "manual"], check=False)
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy.http", "host", host], check=False)
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy.http", "port", port], check=False)
            else:
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy", "mode", "none"], check=False)
            return True
        except Exception as e:
            print("Failed to configure Linux proxy:", e)
            return False

    return False


set_windows_system_proxy = set_system_proxy


class NetFusionMaxEngine:
    def __init__(self, host="127.0.0.1", port=8888):
        self.host = host
        self.port = port
        self.running = False
        self.lock = threading.Lock()

        # Settings & Data
        self.settings = self.load_settings()
        self.data = self.load_data()

        # Operational Mode: 'BOOST' or 'CONTROL'
        self.mode = self.settings.get("operational_mode", "BOOST")

        # Multi-Interface Bonding & Routing
        self.primary_ip = None
        self.secondary_ip = None
        self.rr_index = 0
        self.interface_health = {}  # ip -> {"latency_ms": 0, "alive": True}

        # Real-time Per-Interface Metrics
        self.prev_nic_io = {}       # nic_name -> (bytes_sent, bytes_recv)
        self.nic_speeds = {}        # nic_name -> {"rx_speed": float, "tx_speed": float}
        self.last_tick = time.time()

        # App monitoring & process freezing
        self.suspended_pids = set()
        self.active_pids_cache = {}
        self.process_prev_io = {}
        self.running_processes_cache = {}

        # Proxy Server
        self.server_socket = None
        self.proxy_thread = None
        self.watchdog_thread = None
        self.monitor_thread = None

        # Auto-detect initial interfaces
        self.refresh_interfaces()

    # ------------------ Persistence ------------------
    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    cfg = DEFAULT_SETTINGS.copy()
                    cfg.update(data)
                    return cfg
            except Exception:
                pass
        return DEFAULT_SETTINGS.copy()

    def save_settings(self):
        try:
            tmp = SETTINGS_FILE + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4)
            if os.path.exists(SETTINGS_FILE):
                os.replace(tmp, SETTINGS_FILE)
            else:
                os.rename(tmp, SETTINGS_FILE)
        except Exception as e:
            print("Error saving settings:", e)

    def load_data(self):
        today = datetime.date.today().isoformat()
        initial = {
            "date": today,
            "interfaces": {},       # nic_name -> {"rx": 0, "tx": 0, "ip": ""}
            "app_usage": {},        # app_name -> total_bytes
            "app_nic": {},          # app_name -> nic_name
            "notified_fup": {},     # nic_name -> bool
            "notified_cap": {}      # nic_name -> bool
        }
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if loaded.get("date") == today:
                        initial.update(loaded)
            except Exception:
                pass

        # If app_usage is empty, also migrate from guardian_data.json if present
        if not initial.get("app_usage"):
            guardian_file = os.path.join(BASE_DIR, "guardian_data.json")
            if os.path.exists(guardian_file):
                try:
                    with open(guardian_file, "r", encoding="utf-8") as gf:
                        g_data = json.load(gf)
                        if g_data.get("date") == today and g_data.get("app_usage"):
                            initial["app_usage"] = g_data["app_usage"]
                except Exception:
                    pass

        return initial

    def save_data(self):
        with self.lock:
            try:
                tmp = DATA_FILE + ".tmp"
                with open(tmp, "w", encoding="utf-8") as f:
                    json.dump(self.data, f, indent=4)
                if os.path.exists(DATA_FILE):
                    os.replace(tmp, DATA_FILE)
                else:
                    os.rename(tmp, DATA_FILE)
            except Exception as e:
                print("Error saving data:", e)

    # ------------------ Interface Discovery & Quotas ------------------
    def get_available_interfaces(self):
        """Discovers all active network interfaces with non-loopback IPv4 addresses."""
        result = []
        stats = psutil.net_if_stats()
        addrs = psutil.net_if_addrs()

        for nic_name, nic_addrs in addrs.items():
            stat = stats.get(nic_name)
            if not stat or not stat.isup:
                continue

            for addr in nic_addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith("127.") and not addr.address.startswith("169.254."):
                    result.append({
                        "name": nic_name,
                        "ip": addr.address,
                        "speed": stat.speed,
                        "status": "Up"
                    })
        return result

    def refresh_interfaces(self):
        """Refreshes primary and secondary interfaces if not set or changed."""
        ifaces = self.get_available_interfaces()
        with self.lock:
            if not self.primary_ip and ifaces:
                self.primary_ip = ifaces[0]["ip"]
                self.interface_health[self.primary_ip] = {"latency_ms": 15, "alive": True}
            if not self.secondary_ip and len(ifaces) > 1:
                self.secondary_ip = ifaces[1]["ip"]
                self.interface_health[self.secondary_ip] = {"latency_ms": 20, "alive": True}

    def get_interface_quota(self, nic_name):
        """Returns (daily_cap_gb, warning_fup_gb) for a given interface."""
        quotas = self.settings.get("interface_quotas", {})
        if nic_name in quotas:
            q = quotas[nic_name]
            return float(q.get("daily_cap_gb", 28.0)), float(q.get("warning_fup_gb", 20.0))
        d = quotas.get("default", {"daily_cap_gb": 28.0, "warning_fup_gb": 20.0})
        return float(d.get("daily_cap_gb", 28.0)), float(d.get("warning_fup_gb", 20.0))

    def set_interface_quota(self, nic_name, daily_cap_gb, warning_fup_gb):
        with self.lock:
            if "interface_quotas" not in self.settings:
                self.settings["interface_quotas"] = {}
            self.settings["interface_quotas"][nic_name] = {
                "daily_cap_gb": float(daily_cap_gb),
                "warning_fup_gb": float(warning_fup_gb)
            }
        self.save_settings()

    # ------------------ Core Background Monitor ------------------
    def start(self):
        if self.running:
            return
        self.running = True

        # Initialize baseline NIC counters
        io = psutil.net_io_counters(pernic=True)
        for nic, counters in io.items():
            self.prev_nic_io[nic] = (counters.bytes_sent, counters.bytes_recv)
            self.nic_speeds[nic] = {"rx_speed": 0.0, "tx_speed": 0.0}

        # Start Proxy Server
        self.proxy_thread = threading.Thread(target=self._run_proxy_server, daemon=True)
        self.proxy_thread.start()

        # Start Health Watchdog
        self.watchdog_thread = threading.Thread(target=self._health_watchdog, daemon=True)
        self.watchdog_thread.start()

        # Start Bandwidth & App Monitor Thread
        self.monitor_thread = threading.Thread(target=self._background_monitor_loop, daemon=True)
        self.monitor_thread.start()

    def stop(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass
        self.save_data()

    def _background_monitor_loop(self):
        save_counter = 0
        while self.running:
            time.sleep(1.0)
            now = time.time()
            dt = max(0.1, now - self.last_tick)
            self.last_tick = now

            # 1. Midnight Rollover Check
            today = datetime.date.today().isoformat()
            if self.data.get("date") != today:
                with self.lock:
                    self.data["date"] = today
                    self.data["interfaces"] = {}
                    self.data["app_usage"] = {}
                    self.data["app_nic"] = {}
                    self.data["notified_fup"] = {}
                    self.data["notified_cap"] = {}
                    self.resume_all_apps()
                self.save_data()

            # 2. Update Per-Interface IO & Speeds
            current_nic_io = psutil.net_io_counters(pernic=True)
            active_ifaces = self.get_available_interfaces()
            iface_name_to_ip = {ifc["name"]: ifc["ip"] for ifc in active_ifaces}

            for nic, counters in current_nic_io.items():
                if nic not in self.prev_nic_io:
                    self.prev_nic_io[nic] = (counters.bytes_sent, counters.bytes_recv)
                    self.nic_speeds[nic] = {"rx_speed": 0.0, "tx_speed": 0.0}
                    continue

                prev_tx, prev_rx = self.prev_nic_io[nic]
                cur_tx, cur_rx = counters.bytes_sent, counters.bytes_recv

                # Handle reboot/counter wrap
                delta_tx = max(0, cur_tx - prev_tx) if cur_tx >= prev_tx else cur_tx
                delta_rx = max(0, cur_rx - prev_rx) if cur_rx >= prev_rx else cur_rx
                self.prev_nic_io[nic] = (cur_tx, cur_rx)

                rx_speed = delta_rx / dt
                tx_speed = delta_tx / dt
                self.nic_speeds[nic] = {"rx_speed": rx_speed, "tx_speed": tx_speed}

                # Only accumulate for active non-loopback interfaces
                if nic in iface_name_to_ip or delta_rx > 0 or delta_tx > 0:
                    with self.lock:
                        if nic not in self.data["interfaces"]:
                            self.data["interfaces"][nic] = {
                                "rx": 0.0,
                                "tx": 0.0,
                                "ip": iface_name_to_ip.get(nic, "")
                            }
                        self.data["interfaces"][nic]["rx"] += delta_rx
                        self.data["interfaces"][nic]["tx"] += delta_tx
                        if nic in iface_name_to_ip:
                            self.data["interfaces"][nic]["ip"] = iface_name_to_ip[nic]

            # 3. Check Per-Interface FUP Limits & Auto-Pause
            for nic, info in list(self.data["interfaces"].items()):
                total_nic_bytes = info.get("rx", 0.0) + info.get("tx", 0.0)
                total_nic_gb = total_nic_bytes / (1024**3)
                cap_limit, fup_limit = self.get_interface_quota(nic)

                if total_nic_gb >= fup_limit:
                    if not self.data.get("notified_fup", {}).get(nic):
                        if "notified_fup" not in self.data:
                            self.data["notified_fup"] = {}
                        self.data["notified_fup"][nic] = True
                        if self.settings.get("auto_pause_fup", True):
                            self.pause_heavy_apps()

                if total_nic_gb >= cap_limit:
                    if not self.data.get("notified_cap", {}).get(nic):
                        if "notified_cap" not in self.data:
                            self.data["notified_cap"] = {}
                        self.data["notified_cap"][nic] = True
                        if self.settings.get("auto_pause_cap", True):
                            self.pause_heavy_apps()

            # 4. App Network Inspection
            self._update_app_network_stats()

            # 5. Periodically persist state
            save_counter += 1
            if save_counter >= 5:
                self.save_data()
                save_counter = 0

    def _update_app_network_stats(self):
        """Maps active network connections to processes and attributes bytes to apps (exact original NetGuardian algorithm)."""
        try:
            active_pids = set()
            for c in psutil.net_connections(kind="inet"):
                if c.pid:
                    active_pids.add(c.pid)

            new_running = {}
            with self.lock:
                for pid in active_pids:
                    try:
                        p = psutil.Process(pid)
                        name = p.name()
                        new_running.setdefault(name.lower(), []).append(pid)
                        self.active_pids_cache[pid] = name

                        io = p.io_counters()
                        current_io_bytes = io.read_bytes + io.write_bytes

                        if pid in self.process_prev_io:
                            prev_bytes = self.process_prev_io[pid]
                            d_bytes = current_io_bytes - prev_bytes
                            if 0 < d_bytes < 1024**3:  # sanity check < 1GB per second
                                self.data["app_usage"][name] = self.data["app_usage"].get(name, 0) + d_bytes

                        self.process_prev_io[pid] = current_io_bytes
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass

                self.running_processes_cache = new_running
        except Exception:
            pass

    # ------------------ Process Freezing / Thawing ------------------
    def pause_heavy_apps(self):
        """Freezes known bandwidth-heavy background downloaders safely in memory."""
        heavy_names = set(a.lower() for a in self.settings.get("heavy_apps", []))
        paused_count = 0

        for proc in psutil.process_iter(["pid", "name"]):
            try:
                pname = proc.info["name"]
                if pname and pname.lower() in heavy_names:
                    pid = proc.info["pid"]
                    if pid not in self.suspended_pids:
                        p = psutil.Process(pid)
                        p.suspend()
                        self.suspended_pids.add(pid)
                        paused_count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue
        return paused_count

    def resume_all_apps(self):
        """Resumes all previously frozen applications."""
        resumed_count = 0
        for pid in list(self.suspended_pids):
            try:
                if psutil.pid_exists(pid):
                    p = psutil.Process(pid)
                    p.resume()
                resumed_count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
            finally:
                self.suspended_pids.discard(pid)
        return resumed_count

    def toggle_process_state(self, process_name):
        """Toggles suspend/resume for a specific application name."""
        target_name = process_name.lower()
        matching_pids = []
        is_suspended = False

        for proc in psutil.process_iter(["pid", "name"]):
            try:
                if proc.info["name"] and proc.info["name"].lower() == target_name:
                    matching_pids.append(proc.info["pid"])
                    if proc.info["pid"] in self.suspended_pids:
                        is_suspended = True
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        count = 0
        for pid in matching_pids:
            try:
                p = psutil.Process(pid)
                if is_suspended:
                    p.resume()
                    self.suspended_pids.discard(pid)
                else:
                    p.suspend()
                    self.suspended_pids.add(pid)
                count += 1
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        return not is_suspended, count

    # ------------------ Proxy Engine & Channel Bonding ------------------
    def _run_proxy_server(self):
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            self.server_socket.bind((self.host, self.port))
            self.server_socket.listen(256)
        except Exception as e:
            print(f"Failed to bind proxy on {self.host}:{self.port} - {e}")
            return

        while self.running:
            try:
                client_sock, client_addr = self.server_socket.accept()
                t = threading.Thread(target=self._handle_client_connection, args=(client_sock,), daemon=True)
                t.start()
            except Exception:
                if not self.running:
                    break

    def _select_outgoing_interface(self, target_host, target_port):
        """Selects interface based on BOOST (round-robin) or CONTROL (policy routing)."""
        with self.lock:
            p_alive = self.interface_health.get(self.primary_ip, {}).get("alive", True) if self.primary_ip else False
            s_alive = self.interface_health.get(self.secondary_ip, {}).get("alive", True) if self.secondary_ip else False

            # Automatic Failover
            if not p_alive and s_alive:
                return self.secondary_ip
            if not s_alive and p_alive:
                return self.primary_ip
            if not p_alive and not s_alive:
                return self.primary_ip or None

            if self.mode == "CONTROL":
                # Control Mode: Low latency (voice, games) -> Secondary; Downloads/Web -> Primary
                if target_port in [50000, 50001, 50002, 3724, 6112, 27015, 27016, 8080]:
                    return self.secondary_ip or self.primary_ip
                return self.primary_ip

            # Boost Mode: Channel bonding round-robin
            if self.primary_ip and self.secondary_ip:
                self.rr_index = (self.rr_index + 1) % 2
                return self.secondary_ip if self.rr_index == 1 else self.primary_ip

            return self.primary_ip

    def _handle_client_connection(self, client_sock):
        try:
            client_sock.settimeout(10.0)
            request_data = client_sock.recv(8192)
            if not request_data:
                client_sock.close()
                return

            first_line = request_data.split(b"\r\n")[0].decode("latin-1", errors="replace")
            parts = first_line.split(" ")
            if len(parts) < 3:
                client_sock.close()
                return

            method, url, version = parts[0], parts[1], parts[2]
            target_host = ""
            target_port = 80

            if method.upper() == "CONNECT":
                # HTTPS Tunneling
                if ":" in url:
                    target_host, port_str = url.split(":", 1)
                    target_port = int(port_str)
                else:
                    target_host = url
                    target_port = 443
            else:
                # Plain HTTP
                if "://" in url:
                    url = url.split("://", 1)[1]
                path_parts = url.split("/", 1)
                host_port = path_parts[0]
                if ":" in host_port:
                    target_host, port_str = host_port.split(":", 1)
                    target_port = int(port_str)
                else:
                    target_host = host_port
                    target_port = 80

            # Select bonded interface
            bind_ip = self._select_outgoing_interface(target_host, target_port)

            remote_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            remote_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)

            if bind_ip:
                try:
                    remote_sock.bind((bind_ip, 0))
                except Exception as e:
                    print(f"Warning: Failed to bind to {bind_ip}: {e}")

            remote_sock.settimeout(10.0)
            remote_sock.connect((target_host, target_port))

            if method.upper() == "CONNECT":
                # Acknowledge HTTPS tunnel establishment
                client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
            else:
                # Forward initial HTTP request
                remote_sock.sendall(request_data)

            # Bidirectional streaming relay
            self._relay_traffic(client_sock, remote_sock)

        except Exception:
            pass
        finally:
            try:
                client_sock.close()
            except Exception:
                pass

    def _relay_traffic(self, sock1, sock2):
        sock1.setblocking(False)
        sock2.setblocking(False)
        buffer_size = 65536  # 64 KB buffers for high throughput

        while self.running:
            try:
                rlist, _, xlist = select.select([sock1, sock2], [], [sock1, sock2], 20.0)
                if xlist or not rlist:
                    break

                for s in rlist:
                    other = sock2 if s is sock1 else sock1
                    data = s.recv(buffer_size)
                    if not data:
                        return
                    other.sendall(data)
            except Exception:
                break

    def _health_watchdog(self):
        """Periodically pings DNS (1.1.1.1:53) over each adapter to check latency & health."""
        while self.running:
            time.sleep(4.0)
            for ip in [self.primary_ip, self.secondary_ip]:
                if not ip:
                    continue
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(2.0)
                    s.bind((ip, 0))
                    t0 = time.time()
                    s.connect(("1.1.1.1", 53))
                    latency = (time.time() - t0) * 1000.0
                    s.close()
                    with self.lock:
                        self.interface_health[ip] = {"latency_ms": round(latency, 1), "alive": True}
                except Exception:
                    with self.lock:
                        self.interface_health[ip] = {"latency_ms": 999, "alive": False}
