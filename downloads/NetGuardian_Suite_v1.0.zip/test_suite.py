"""
NetGuardian & NetFusion Comprehensive Test Suite
Validates all core functionality, networking routines, process suspension,
proxy routing, bonding logic, and settings persistence.
"""

import sys
import os
import time
import socket
import json
import urllib.request
import winreg
import psutil

# Ensure current directory is in sys.path
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
if BASE_DIR not in sys.path:
    sys.path.insert(0, BASE_DIR)

from net_fusion_engine import NetFusionEngine, set_windows_system_proxy
import net_guardian_app

passed_tests = 0
failed_tests = 0

def test_assert(name, condition, details=""):
    global passed_tests, failed_tests
    if condition:
        passed_tests += 1
        print(f"  [PASS] {name} {details}")
    else:
        failed_tests += 1
        print(f"  [FAIL] {name} {details}")


print("=" * 60)
print("       NETGUARDIAN & NETFUSION FULL TEST SUITE")
print("=" * 60)

# ==============================================================================
# SECTION 1: NETGUARDIAN TESTS
# ==============================================================================
print("\n>>> TESTING NETGUARDIAN CORE MODULES...")

# 1.1 Helper formatting functions
test_assert(
    "format_bytes (GB)",
    net_guardian_app.format_bytes(25 * (1024**3)) == "25.00 GB",
    f"Got: {net_guardian_app.format_bytes(25 * (1024**3))}"
)
test_assert(
    "format_bytes (MB)",
    net_guardian_app.format_bytes(450 * (1024**2)) == "450.0 MB",
    f"Got: {net_guardian_app.format_bytes(450 * (1024**2))}"
)
test_assert(
    "format_speed",
    "MB/s" in net_guardian_app.format_speed(2.5 * (1024**2)),
    f"Got: {net_guardian_app.format_speed(2.5 * (1024**2))}"
)

# 1.2 Settings persistence
app_instance = net_guardian_app.NetGuardianApp.__new__(net_guardian_app.NetGuardianApp)
app_instance.settings = net_guardian_app.DEFAULT_SETTINGS.copy()
test_assert("Default Daily Cap is 28 GB", app_instance.settings["daily_cap_gb"] == 28.0)
test_assert("Default Warning is 20 GB", app_instance.settings["warning_fup_gb"] == 20.0)

# 1.3 Kernel Process Suspend and Resume Verification
print("  --> Testing Windows process suspend & resume (zero-loss pausing)...")
try:
    import subprocess
    proc = subprocess.Popen(["ping", "127.0.0.1", "-n", "10"], stdout=subprocess.DEVNULL)
    p = psutil.Process(proc.pid)
    
    # Verify initial running state
    initial_status = p.status()
    p.suspend()
    time.sleep(0.2)
    suspended_status = p.status()
    test_assert("Kernel Suspend (Pause)", suspended_status == "stopped", f"Status: {suspended_status}")

    p.resume()
    time.sleep(0.2)
    resumed_status = p.status()
    test_assert("Kernel Resume (Unpause)", resumed_status == "running", f"Status: {resumed_status}")
    proc.terminate()
except Exception as e:
    test_assert("Kernel Suspend/Resume", False, f"Exception: {e}")

# 1.4 Active Network Socket Enumeration
try:
    conns = [c for c in psutil.net_connections(kind='inet') if c.pid]
    test_assert("Network Connection Tracking", len(conns) > 0, f"Found {len(conns)} active sockets")
except Exception as e:
    test_assert("Network Connection Tracking", False, f"Exception: {e}")


# ==============================================================================
# SECTION 2: NETFUSION CORE ENGINE TESTS
# ==============================================================================
print("\n>>> TESTING NETFUSION ENGINE & BONDING ROUTER...")

engine = NetFusionEngine(port=8999)  # Use custom test port

# 2.1 Interface Discovery
ifaces = engine.get_available_interfaces()
test_assert("Interface Discovery", len(ifaces) >= 1, f"Found {len(ifaces)} active interfaces: {[i['name'] for i in ifaces]}")

if ifaces:
    primary_ip = ifaces[0]["ip"]
    simulated_secondary_ip = "192.168.99.100"
    engine.set_interfaces(primary_ip, simulated_secondary_ip)
    test_assert("Set Primary IP", engine.primary_ip == primary_ip)
    test_assert("Set Secondary IP", engine.secondary_ip == simulated_secondary_ip)

# 2.2 Operational Mode Routing Checks
# Mode A: Boost Mode (Round-Robin alternating)
engine.mode = "BOOST"
out1, tag1 = engine._select_outbound_ip(80)
out2, tag2 = engine._select_outbound_ip(80)
out3, tag3 = engine._select_outbound_ip(80)
test_assert(
    "Boost Mode Alternating Routing",
    out1 != out2,
    f"out1={out1} ({tag1}), out2={out2} ({tag2})"
)

# Mode B: Control Mode (Policy Routing)
engine.mode = "CONTROL"
# Voice/Game port 5060 or 27015 -> Should go to secondary
out_voice, tag_voice = engine._select_outbound_ip(dest_port=5060)
# Bulk download port 80 -> Should go to primary
out_bulk, tag_bulk = engine._select_outbound_ip(dest_port=80)
test_assert(
    "Control Mode Policy Routing (Voice -> Secondary)",
    out_voice == simulated_secondary_ip,
    f"Voice assigned to {tag_voice}"
)
test_assert(
    "Control Mode Policy Routing (Bulk -> Primary)",
    out_bulk == primary_ip,
    f"Bulk assigned to {tag_bulk}"
)

# 2.3 Failover Logic Test
print("  --> Testing automatic failover when primary drops...")
engine.interface_health[primary_ip] = {"latency_ms": 999, "alive": False}
engine.interface_health[simulated_secondary_ip] = {"latency_ms": 25, "alive": True}
failover_ip, failover_tag = engine._select_outbound_ip(80)
test_assert(
    "Automatic Failover to Secondary",
    failover_ip == simulated_secondary_ip,
    f"Selected: {failover_ip} ({failover_tag})"
)

# Restore health
engine.interface_health[primary_ip] = {"latency_ms": 15, "alive": True}

# 2.4 Proxy Server Lifecycle & HTTP Dispatch Test
print("  --> Testing live proxy dispatch on 127.0.0.1:8999...")
engine.set_interfaces(primary_ip, None) # Use primary for live connection
engine.start()
time.sleep(0.5)

try:
    # Test establishing TCP connection to local proxy
    test_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    test_sock.settimeout(3.0)
    test_sock.connect(("127.0.0.1", 8999))
    test_assert("Proxy Server Port Listening", True, "Successfully connected to 127.0.0.1:8999")
    test_sock.close()
except Exception as e:
    test_assert("Proxy Server Port Listening", False, f"Exception: {e}")

engine.stop()

# ==============================================================================
# SECTION 3: WINDOWS SYSTEM PROXY TOGGLE TEST
# ==============================================================================
print("\n>>> TESTING WINDOWS SYSTEM PROXY REGISTRY TOGGLE...")

try:
    # Enable proxy
    res_on = set_windows_system_proxy(enable=True, proxy_server="127.0.0.1:8888")
    reg_key = winreg.OpenKey(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
        0,
        winreg.KEY_READ
    )
    val_on, _ = winreg.QueryValueEx(reg_key, "ProxyEnable")
    test_assert("Windows System Proxy Enable", res_on and val_on == 1, f"ProxyEnable={val_on}")

    # Disable proxy
    res_off = set_windows_system_proxy(enable=False)
    val_off, _ = winreg.QueryValueEx(reg_key, "ProxyEnable")
    winreg.CloseKey(reg_key)
    test_assert("Windows System Proxy Disable (Clean Restore)", res_off and val_off == 0, f"ProxyEnable={val_off}")
except Exception as e:
    test_assert("Windows System Proxy Toggle", False, f"Exception: {e}")


# ==============================================================================
# SUMMARY
# ==============================================================================
print("\n" + "=" * 60)
print(f"TEST RESULTS: {passed_tests} PASSED, {failed_tests} FAILED")
print("=" * 60)

if failed_tests == 0:
    print("ALL TESTS COMPLETED SUCCESSFULLY! BOTH APPS ARE 100% OPERATIONAL.\n")
    sys.exit(0)
else:
    print("SOME TESTS FAILED.\n")
    sys.exit(1)
