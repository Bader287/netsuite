"""
NetGuardian - Bandwidth & FUP Quota Guardian
A modern desktop application to track real-time network speeds, monitor daily ISP quotas,
break down per-application Wi-Fi usage, and automatically pause heavy background downloaders.
"""

import sys
import os
import json
import time
import threading
import datetime
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk
import psutil

# Configuration and persistence paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "guardian_data.json")
SETTINGS_FILE = os.path.join(BASE_DIR, "guardian_settings.json")

# Default settings
DEFAULT_SETTINGS = {
    "daily_cap_gb": 28.0,
    "warning_fup_gb": 20.0,
    "auto_pause_fup": True,
    "auto_pause_cap": True,
    "sound_alerts": True,
    "heavy_apps": [
        "steam.exe", "steamservice.exe",
        "epicgameslauncher.exe",
        "riotclientservices.exe", "valorant.exe",
        "battle.net.exe", "agent.exe",
        "eadesktop.exe", "eabackgroundservice.exe",
        "upc.exe", "ubisoftconnect.exe",
        "qbittorrent.exe", "utorrent.exe", "bittorrent.exe",
        "onedrive.exe", "googledrivesync.exe", "dropbox.exe"
    ]
}

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")


def format_bytes(b):
    if b >= 1024**3:
        return f"{b / (1024**3):.2f} GB"
    elif b >= 1024**2:
        return f"{b / (1024**2):.1f} MB"
    elif b >= 1024:
        return f"{b / 1024:.1f} KB"
    else:
        return f"{int(b)} B"


def format_speed(bps):
    if bps >= 1024**2:
        return f"{bps / (1024**2):.2f} MB/s"
    elif bps >= 1024:
        return f"{bps / 1024:.1f} KB/s"
    else:
        return f"{int(bps)} B/s"


class NetGuardianApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("NetGuardian - Bandwidth & Quota Controller")
        self.geometry("980x760")
        self.minsize(880, 680)

        # Set Window and Taskbar Icon
        ico_path = os.path.join(BASE_DIR, "net_guardian.ico")
        if os.path.exists(ico_path):
            try:
                self.iconbitmap(ico_path)
            except Exception:
                pass

        # Load settings and data
        self.settings = self.load_settings()
        self.data = self.load_data()

        # State tracking
        self.running = True
        self.prev_net_io = psutil.net_io_counters()
        self.last_tick = time.time()
        self.current_rx_speed = 0.0
        self.current_tx_speed = 0.0
        self.suspended_pids = set()
        self.process_prev_io = {}
        self.app_rows = {}
        self.running_processes_cache = {}

        # Build UI
        self.setup_ui()

        # Start background monitor thread
        self.monitor_thread = threading.Thread(target=self.background_monitor, daemon=True)
        self.monitor_thread.start()

        # Scheduled periodic UI refresh
        self.refresh_ui()

    def load_settings(self):
        if os.path.exists(SETTINGS_FILE):
            try:
                with open(SETTINGS_FILE, "r", encoding="utf-8") as f:
                    data = json.load(f)
                    res = DEFAULT_SETTINGS.copy()
                    res.update(data)
                    return res
            except Exception:
                pass
        return DEFAULT_SETTINGS.copy()

    def save_settings(self):
        try:
            with open(SETTINGS_FILE, "w", encoding="utf-8") as f:
                json.dump(self.settings, f, indent=4)
        except Exception as e:
            print("Failed to save settings:", e)

    def load_data(self):
        today = datetime.date.today().isoformat()
        initial = {
            "date": today,
            "total_rx": 0.0,
            "total_tx": 0.0,
            "app_usage": {},
            "notified_fup": False,
            "notified_cap": False
        }
        if os.path.exists(DATA_FILE):
            try:
                with open(DATA_FILE, "r", encoding="utf-8") as f:
                    loaded = json.load(f)
                    if loaded.get("date") == today:
                        return loaded
            except Exception:
                pass
        return initial

    def save_data(self):
        try:
            temp_file = DATA_FILE + ".tmp"
            with open(temp_file, "w", encoding="utf-8") as f:
                json.dump(self.data, f, indent=4)
            os.replace(temp_file, DATA_FILE)
        except Exception as e:
            print("Failed to save data:", e)

    def setup_ui(self):
        # Configure layout
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(2, weight=1)

        # Header Frame
        header = ctk.CTkFrame(self, corner_radius=12, fg_color="#181a20")
        header.grid(row=0, column=0, padx=16, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=0, padx=16, pady=12, sticky="w")

        title_lbl = ctk.CTkLabel(title_box, text="⚡ NetGuardian", font=ctk.CTkFont(size=22, weight="bold"), text_color="#00d2ff")
        title_lbl.pack(anchor="w")

        sub_lbl = ctk.CTkLabel(title_box, text="FUP Bandwidth & Per-App Data Controller", font=ctk.CTkFont(size=12), text_color="#8892b0")
        sub_lbl.pack(anchor="w")

        # Live Speed Cards
        speed_box = ctk.CTkFrame(header, fg_color="transparent")
        speed_box.grid(row=0, column=1, padx=16, pady=8, sticky="e")

        self.speed_down_lbl = ctk.CTkLabel(speed_box, text="▼ 0.00 MB/s", font=ctk.CTkFont(size=16, weight="bold"), text_color="#00ff88")
        self.speed_down_lbl.pack(side="left", padx=12)

        self.speed_up_lbl = ctk.CTkLabel(speed_box, text="▲ 0.00 MB/s", font=ctk.CTkFont(size=16, weight="bold"), text_color="#3a86ff")
        self.speed_up_lbl.pack(side="left", padx=12)

        self.status_badge = ctk.CTkLabel(speed_box, text="NORMAL SPEED", font=ctk.CTkFont(size=12, weight="bold"),
                                         fg_color="#1e3a2f", text_color="#00ff88", corner_radius=8, padx=12, pady=4)
        self.status_badge.pack(side="left", padx=8)

        # Quota & Control Dashboard Frame
        dashboard = ctk.CTkFrame(self, corner_radius=12, fg_color="#1a1c23")
        dashboard.grid(row=1, column=0, padx=16, pady=6, sticky="ew")
        dashboard.grid_columnconfigure((0, 1), weight=1)

        # Left Column: Progress Bars & Stats
        stats_frame = ctk.CTkFrame(dashboard, fg_color="transparent")
        stats_frame.grid(row=0, column=0, padx=16, pady=12, sticky="nsew")

        self.cap_title_lbl = ctk.CTkLabel(stats_frame, text="Daily Data Cap (28.0 GB)", font=ctk.CTkFont(size=13, weight="bold"))
        self.cap_title_lbl.pack(anchor="w")

        self.cap_bar = ctk.CTkProgressBar(stats_frame, height=14, corner_radius=6, progress_color="#00d2ff", fg_color="#2b2d42")
        self.cap_bar.pack(fill="x", pady=(4, 2))
        self.cap_bar.set(0)

        self.cap_detail_lbl = ctk.CTkLabel(stats_frame, text="0.00 GB / 28.00 GB (0.0%) - 28.00 GB remaining", font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.cap_detail_lbl.pack(anchor="w", pady=(0, 10))

        self.fup_title_lbl = ctk.CTkLabel(stats_frame, text="FUP Slowdown Zone (20.0 GB)", font=ctk.CTkFont(size=13, weight="bold"))
        self.fup_title_lbl.pack(anchor="w")

        self.fup_bar = ctk.CTkProgressBar(stats_frame, height=14, corner_radius=6, progress_color="#ffbe0b", fg_color="#2b2d42")
        self.fup_bar.pack(fill="x", pady=(4, 2))
        self.fup_bar.set(0)

        self.fup_detail_lbl = ctk.CTkLabel(stats_frame, text="0.00 GB / 20.00 GB (0.0%) - 20.00 GB remaining to slowdown", font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.fup_detail_lbl.pack(anchor="w")

        # Right Column: Custom Quota Inputs & Quick Actions
        controls_frame = ctk.CTkFrame(dashboard, fg_color="transparent")
        controls_frame.grid(row=0, column=1, padx=16, pady=12, sticky="nsew")

        row1 = ctk.CTkFrame(controls_frame, fg_color="transparent")
        row1.pack(fill="x", pady=2)

        ctk.CTkLabel(row1, text="Daily Limit (GB):", font=ctk.CTkFont(size=12)).pack(side="left", padx=(0, 6))
        self.cap_entry = ctk.CTkEntry(row1, width=70, height=28)
        self.cap_entry.insert(0, str(self.settings.get("daily_cap_gb", 28.0)))
        self.cap_entry.pack(side="left", padx=4)

        ctk.CTkLabel(row1, text="FUP Warning (GB):", font=ctk.CTkFont(size=12)).pack(side="left", padx=(14, 6))
        self.fup_entry = ctk.CTkEntry(row1, width=70, height=28)
        self.fup_entry.insert(0, str(self.settings.get("warning_fup_gb", 20.0)))
        self.fup_entry.pack(side="left", padx=4)

        save_btn = ctk.CTkButton(row1, text="Apply", width=65, height=28, command=self.apply_quota_settings, fg_color="#2b6cb0", hover_color="#2c5282")
        save_btn.pack(side="left", padx=8)

        # Automation Toggles
        row2 = ctk.CTkFrame(controls_frame, fg_color="transparent")
        row2.pack(fill="x", pady=(8, 2))

        self.auto_pause_var = ctk.BooleanVar(value=self.settings.get("auto_pause_fup", True))
        self.auto_pause_chk = ctk.CTkCheckBox(row2, text="Auto-Pause Heavy Downloaders at FUP Limit", variable=self.auto_pause_var,
                                              command=self.toggle_auto_pause, font=ctk.CTkFont(size=11))
        self.auto_pause_chk.pack(side="left")

        # Quick Action Buttons
        row3 = ctk.CTkFrame(controls_frame, fg_color="transparent")
        row3.pack(fill="x", pady=(10, 2))

        self.freeze_btn = ctk.CTkButton(row3, text="⏸ Pause Heavy Hogs", width=140, height=32,
                                        fg_color="#d90429", hover_color="#ef233c", command=self.pause_heavy_apps)
        self.freeze_btn.pack(side="left", padx=(0, 8))

        self.resume_btn = ctk.CTkButton(row3, text="▶ Resume All Apps", width=140, height=32,
                                        fg_color="#10b981", hover_color="#059669", command=self.resume_all_apps)
        self.resume_btn.pack(side="left", padx=4)

        reset_btn = ctk.CTkButton(row3, text="↺ Reset Today", width=100, height=32,
                                  fg_color="#4a5568", hover_color="#2d3748", command=self.reset_today_data)
        reset_btn.pack(side="left", padx=8)

        # Lower Section: Per-Application Usage Table
        app_section = ctk.CTkFrame(self, corner_radius=12, fg_color="#1a1c23")
        app_section.grid(row=2, column=0, padx=16, pady=(6, 14), sticky="nsew")
        app_section.grid_columnconfigure(0, weight=1)
        app_section.grid_rowconfigure(1, weight=1)

        # Section Header
        sec_header = ctk.CTkFrame(app_section, fg_color="transparent")
        sec_header.grid(row=0, column=0, padx=16, pady=(10, 4), sticky="ew")

        ctk.CTkLabel(sec_header, text="📊 Per-Application Network Consumption", font=ctk.CTkFont(size=14, weight="bold"), text_color="#ffffff").pack(side="left")
        self.apps_count_lbl = ctk.CTkLabel(sec_header, text="(0 apps detected)", font=ctk.CTkFont(size=11), text_color="#718096")
        self.apps_count_lbl.pack(side="left", padx=8)

        # Scrollable list for apps
        self.apps_scroll = ctk.CTkScrollableFrame(app_section, fg_color="#14151b", corner_radius=8)
        self.apps_scroll.grid(row=1, column=0, padx=12, pady=(4, 12), sticky="nsew")
        self.apps_scroll.grid_columnconfigure(0, weight=3)  # Name
        self.apps_scroll.grid_columnconfigure(1, weight=1)  # Usage
        self.apps_scroll.grid_columnconfigure(2, weight=1)  # Status
        self.apps_scroll.grid_columnconfigure(3, weight=1)  # Action

        # Render initial table header
        self.render_app_table_headers()

    def render_app_table_headers(self):
        h_frame = ctk.CTkFrame(self.apps_scroll, fg_color="#20222a", corner_radius=6, height=32)
        h_frame.grid(row=0, column=0, columnspan=4, sticky="ew", pady=(0, 6), padx=4)
        h_frame.grid_columnconfigure(0, weight=3)
        h_frame.grid_columnconfigure(1, weight=1)
        h_frame.grid_columnconfigure(2, weight=1)
        h_frame.grid_columnconfigure(3, weight=1)

        ctk.CTkLabel(h_frame, text="Process Name", font=ctk.CTkFont(size=11, weight="bold"), anchor="w").grid(row=0, column=0, padx=12, sticky="w")
        ctk.CTkLabel(h_frame, text="Data Used", font=ctk.CTkFont(size=11, weight="bold"), anchor="center").grid(row=0, column=1, padx=4)
        ctk.CTkLabel(h_frame, text="Status", font=ctk.CTkFont(size=11, weight="bold"), anchor="center").grid(row=0, column=2, padx=4)
        ctk.CTkLabel(h_frame, text="Quick Action", font=ctk.CTkFont(size=11, weight="bold"), anchor="e").grid(row=0, column=3, padx=12, sticky="e")

    def apply_quota_settings(self):
        try:
            new_cap = float(self.cap_entry.get().strip())
            new_fup = float(self.fup_entry.get().strip())
            if new_cap <= 0 or new_fup <= 0:
                raise ValueError("Values must be positive numbers.")
            self.settings["daily_cap_gb"] = new_cap
            self.settings["warning_fup_gb"] = new_fup
            self.save_settings()
            messagebox.showinfo("Settings Applied", f"New Quota configured:\nDaily Cap: {new_cap} GB\nFUP Warning: {new_fup} GB")
        except ValueError:
            messagebox.showerror("Invalid Input", "Please enter valid numeric values for GB quotas.")

    def toggle_auto_pause(self):
        self.settings["auto_pause_fup"] = self.auto_pause_var.get()
        self.save_settings()

    def pause_heavy_apps(self):
        targets = [app.lower() for app in self.settings.get("heavy_apps", [])]
        paused = []
        for proc in psutil.process_iter(['pid', 'name']):
            try:
                name = proc.info['name'].lower()
                pid = proc.info['pid']
                if name in targets and pid not in self.suspended_pids:
                    p = psutil.Process(pid)
                    p.suspend()
                    self.suspended_pids.add(pid)
                    paused.append(f"{proc.info['name']} (PID {pid})")
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                continue

        if paused:
            messagebox.showinfo("Heavy Apps Paused", f"Suspended {len(paused)} download processes:\n" + "\n".join(paused[:8]))
        else:
            messagebox.showinfo("No Heavy Apps Found", "No active heavy background game/download launchers were running.")

    def resume_all_apps(self):
        resumed = 0
        to_remove = set()
        for pid in list(self.suspended_pids):
            try:
                p = psutil.Process(pid)
                p.resume()
                resumed += 1
                to_remove.add(pid)
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                to_remove.add(pid)

        self.suspended_pids.difference_update(to_remove)
        messagebox.showinfo("Apps Resumed", f"Successfully resumed {resumed} applications.")

    def toggle_single_process(self, pid, name):
        try:
            p = psutil.Process(pid)
            if pid in self.suspended_pids:
                p.resume()
                self.suspended_pids.remove(pid)
            else:
                p.suspend()
                self.suspended_pids.add(pid)
        except Exception as e:
            messagebox.showerror("Process Error", f"Could not toggle {name}: {e}")

    def reset_today_data(self):
        if messagebox.askyesno("Reset Today's Data", "Are you sure you want to reset today's tracked data usage back to 0?"):
            self.data["total_rx"] = 0.0
            self.data["total_tx"] = 0.0
            self.data["app_usage"] = {}
            self.data["notified_fup"] = False
            self.data["notified_cap"] = False
            self.save_data()

    def background_monitor(self):
        """Continuously samples network delta and per-process usage."""
        save_counter = 0

        while self.running:
            time.sleep(1.0)
            now = time.time()
            dt = now - self.last_tick
            if dt <= 0:
                dt = 1.0

            # 1. Total Network I/O
            current_net = psutil.net_io_counters()
            delta_rx = current_net.bytes_recv - self.prev_net_io.bytes_recv
            delta_tx = current_net.bytes_sent - self.prev_net_io.bytes_sent

            if delta_rx < 0:
                delta_rx = 0
            if delta_tx < 0:
                delta_tx = 0

            self.current_rx_speed = delta_rx / dt
            self.current_tx_speed = delta_tx / dt
            self.prev_net_io = current_net
            self.last_tick = now

            # Accumulate daily total
            today = datetime.date.today().isoformat()
            if self.data.get("date") != today:
                # Midnight rollover!
                self.data = {
                    "date": today,
                    "total_rx": 0.0,
                    "total_tx": 0.0,
                    "app_usage": {},
                    "notified_fup": False,
                    "notified_cap": False
                }

            self.data["total_rx"] += delta_rx
            self.data["total_tx"] += delta_tx

            # 2. Per-Process IO Sampling for connected apps
            try:
                active_pids = set()
                for c in psutil.net_connections(kind='inet'):
                    if c.pid:
                        active_pids.add(c.pid)

                new_running = {}
                for pid in active_pids:
                    try:
                        p = psutil.Process(pid)
                        name = p.name()
                        new_running.setdefault(name.lower(), []).append(pid)
                        io = p.io_counters()
                        current_io_bytes = io.read_bytes + io.write_bytes

                        if pid in self.process_prev_io:
                            prev_bytes = self.process_prev_io[pid]
                            d_bytes = current_io_bytes - prev_bytes
                            if 0 < d_bytes < 1024**3:  # sanity check < 1GB per second
                                self.data["app_usage"][name] = self.data["app_usage"].get(name, 0) + d_bytes

                        self.process_prev_io[pid] = current_io_bytes
                    except (psutil.NoSuchProcess, psutil.AccessDenied):
                        pass

                self.running_processes_cache = new_running
            except Exception:
                pass

            # 3. Check Auto-Pause Triggers
            total_gb = (self.data["total_rx"] + self.data["total_tx"]) / (1024**3)
            fup_limit = self.settings.get("warning_fup_gb", 20.0)
            cap_limit = self.settings.get("daily_cap_gb", 28.0)

            if total_gb >= fup_limit and not self.data.get("notified_fup"):
                self.data["notified_fup"] = True
                if self.settings.get("auto_pause_fup", True):
                    # Auto-pause heavy downloaders!
                    self.pause_heavy_apps()

            if total_gb >= cap_limit and not self.data.get("notified_cap"):
                self.data["notified_cap"] = True
                if self.settings.get("auto_pause_cap", True):
                    self.pause_heavy_apps()

            # Save periodically
            save_counter += 1
            if save_counter >= 5:
                self.save_data()
                save_counter = 0

    def refresh_ui(self):
        """Updates UI widgets with fresh data every second."""
        total_bytes = self.data["total_rx"] + self.data["total_tx"]
        total_gb = total_bytes / (1024**3)
        cap_gb = self.settings.get("daily_cap_gb", 28.0)
        fup_gb = self.settings.get("warning_fup_gb", 20.0)

        # Speeds
        self.speed_down_lbl.configure(text=f"▼ {format_speed(self.current_rx_speed)}")
        self.speed_up_lbl.configure(text=f"▲ {format_speed(self.current_tx_speed)}")

        # Status badge
        if total_gb >= cap_gb:
            self.status_badge.configure(text=f"CAP EXCEEDED (>{cap_gb:.0f}GB)", fg_color="#4a151b", text_color="#ff4d4d")
        elif total_gb >= fup_gb:
            self.status_badge.configure(text=f"FUP SLOWDOWN (>{fup_gb:.0f}GB)", fg_color="#4a3a10", text_color="#ffbe0b")
        elif total_gb >= (fup_gb - 3.0):
            self.status_badge.configure(text="APPROACHING FUP", fg_color="#3a3010", text_color="#ffd166")
        else:
            self.status_badge.configure(text="NORMAL SPEED", fg_color="#1e3a2f", text_color="#00ff88")

        # Daily Cap Progress
        cap_frac = min(1.0, total_gb / cap_gb) if cap_gb > 0 else 0
        self.cap_bar.set(cap_frac)
        rem_cap = max(0.0, cap_gb - total_gb)
        self.cap_title_lbl.configure(text=f"Daily Data Cap ({cap_gb:.1f} GB)")
        self.cap_detail_lbl.configure(
            text=f"{total_gb:.2f} GB / {cap_gb:.2f} GB ({cap_frac*100:.1f}%) - {rem_cap:.2f} GB remaining"
        )

        # FUP Progress
        fup_frac = min(1.0, total_gb / fup_gb) if fup_gb > 0 else 0
        self.fup_bar.set(fup_frac)
        rem_fup = max(0.0, fup_gb - total_gb)
        self.fup_title_lbl.configure(text=f"FUP Slowdown Zone ({fup_gb:.1f} GB)")
        self.fup_detail_lbl.configure(
            text=f"{total_gb:.2f} GB / {fup_gb:.2f} GB ({fup_frac*100:.1f}%) - {rem_fup:.2f} GB remaining to slowdown"
        )

        # Refresh per-application list
        self.update_apps_table()

        # Reschedule next refresh
        self.after(1000, self.refresh_ui)

    def update_apps_table(self):
        """Smoothly updates the per-app data usage table in-place without destroying widgets or flickering."""
        app_usage = self.data.get("app_usage", {})
        sorted_apps = sorted(app_usage.items(), key=lambda x: x[1], reverse=True)
        self.apps_count_lbl.configure(text=f"({len(sorted_apps)} apps tracked today)")

        top_apps = sorted_apps[:30]
        top_names_set = set(name.lower() for name, _ in top_apps)
        heavy_set = set(a.lower() for a in self.settings.get("heavy_apps", []))
        running_names = self.running_processes_cache

        # Hide any rows that dropped out of the top 30
        for name_lower, row_data in self.app_rows.items():
            if name_lower not in top_names_set:
                row_data["frame"].grid_remove()

        # Update or create rows in place
        for row_idx, (name, bytes_used) in enumerate(top_apps, start=1):
            name_lower = name.lower()
            pids = running_names.get(name_lower, [])
            is_running = len(pids) > 0
            is_suspended = any(pid in self.suspended_pids for pid in pids)
            target_pid = pids[0] if is_running else None

            # First time seeing this app: construct row once
            if name_lower not in self.app_rows:
                row_frame = ctk.CTkFrame(self.apps_scroll, fg_color="#181a22", corner_radius=6, height=36)
                row_frame.grid_columnconfigure(0, weight=3)
                row_frame.grid_columnconfigure(1, weight=1)
                row_frame.grid_columnconfigure(2, weight=1)
                row_frame.grid_columnconfigure(3, weight=1)

                is_heavy = name_lower in heavy_set
                prefix = "🎮 " if is_heavy else "🌐 "

                name_lbl = ctk.CTkLabel(row_frame, text=f"{prefix}{name}", font=ctk.CTkFont(size=12), anchor="w")
                name_lbl.grid(row=0, column=0, padx=12, sticky="w")

                usage_lbl = ctk.CTkLabel(row_frame, text=format_bytes(bytes_used), font=ctk.CTkFont(size=12, weight="bold"),
                                         text_color="#00d2ff" if bytes_used > 100*1024*1024 else "#e2e8f0")
                usage_lbl.grid(row=0, column=1, padx=4)

                status_lbl = ctk.CTkLabel(row_frame, text="RUNNING" if is_running else "OFFLINE",
                                          font=ctk.CTkFont(size=10, weight="bold"), corner_radius=6, padx=8)
                status_lbl.grid(row=0, column=2, padx=4)

                action_btn = ctk.CTkButton(row_frame, text="⏸ Pause", width=75, height=24, font=ctk.CTkFont(size=10))
                action_btn.grid(row=0, column=3, padx=12, sticky="e")

                placeholder_lbl = ctk.CTkLabel(row_frame, text="-", font=ctk.CTkFont(size=11), text_color="#4a5568")

                self.app_rows[name_lower] = {
                    "frame": row_frame,
                    "name_lbl": name_lbl,
                    "usage_lbl": usage_lbl,
                    "status_lbl": status_lbl,
                    "action_btn": action_btn,
                    "placeholder_lbl": placeholder_lbl,
                    "last_bytes": -1,
                    "last_status": None,
                    "last_pid": None
                }

            row_data = self.app_rows[name_lower]

            # 1. Update grid row position if changed
            info = row_data["frame"].grid_info()
            if not info or info.get("row") != row_idx:
                row_data["frame"].grid(row=row_idx, column=0, columnspan=4, sticky="ew", pady=2, padx=4)

            # 2. Update usage label ONLY if number changed
            if row_data["last_bytes"] != bytes_used:
                row_data["usage_lbl"].configure(
                    text=format_bytes(bytes_used),
                    text_color="#00d2ff" if bytes_used > 100*1024*1024 else "#e2e8f0"
                )
                row_data["last_bytes"] = bytes_used

            # 3. Determine status string
            status_key = "PAUSED" if is_suspended else ("RUNNING" if is_running else "OFFLINE")
            if row_data["last_status"] != status_key or row_data["last_pid"] != target_pid:
                if is_suspended:
                    row_data["status_lbl"].configure(text="PAUSED", text_color="#ffbe0b", fg_color="#3a2f10", font=ctk.CTkFont(size=10, weight="bold"))
                    row_data["action_btn"].configure(
                        text="▶ Resume", fg_color="#10b981", hover_color="#059669",
                        command=lambda p=target_pid, n=name: self.toggle_single_process(p, n)
                    )
                    row_data["placeholder_lbl"].grid_remove()
                    row_data["action_btn"].grid(row=0, column=3, padx=12, sticky="e")
                elif is_running:
                    row_data["status_lbl"].configure(text="RUNNING", text_color="#00ff88", fg_color="#103a20", font=ctk.CTkFont(size=10, weight="bold"))
                    row_data["action_btn"].configure(
                        text="⏸ Pause", fg_color="#ef4444", hover_color="#dc2626",
                        command=lambda p=target_pid, n=name: self.toggle_single_process(p, n)
                    )
                    row_data["placeholder_lbl"].grid_remove()
                    row_data["action_btn"].grid(row=0, column=3, padx=12, sticky="e")
                else:
                    row_data["status_lbl"].configure(text="OFFLINE", text_color="#718096", fg_color="#1f232d", font=ctk.CTkFont(size=10))
                    row_data["action_btn"].grid_remove()
                    row_data["placeholder_lbl"].grid(row=0, column=3, padx=24, sticky="e")

                row_data["last_status"] = status_key
                row_data["last_pid"] = target_pid


if __name__ == "__main__":
    app = NetGuardianApp()
    app.mainloop()
