@echo off
title Install NetGuardian Desktop Shortcut
cd /d "%~dp0"

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
"$WshShell = New-Object -ComObject WScript.Shell; ^
$DesktopPath = [Environment]::GetFolderPath('Desktop'); ^
$Shortcut = $WshShell.CreateShortcut(\"$DesktopPath\NetGuardian.lnk\"); ^
$Shortcut.TargetPath = 'C:\Users\bader\AppData\Local\Python\bin\pythonw.exe'; ^
$Shortcut.Arguments = '\"%~dp0net_guardian_app.py\"'; ^
$Shortcut.WorkingDirectory = '%~dp0'; ^
$Shortcut.WindowStyle = 1; ^
$Shortcut.Description = 'NetGuardian - ISP Bandwidth & FUP Quota Controller'; ^
$Shortcut.IconLocation = '%~dp0net_guardian.ico'; ^
$Shortcut.Save(); ^
Write-Host 'NetGuardian Desktop application shortcut created successfully!' -ForegroundColor Green"

echo.
pause
