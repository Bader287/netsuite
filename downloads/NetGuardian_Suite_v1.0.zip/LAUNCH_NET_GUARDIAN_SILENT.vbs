Set WshShell = CreateObject("WScript.Shell")
WshShell.Run "pyw net_guardian_app.py", 0, False
