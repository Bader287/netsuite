"""
NetFusion Desktop Application
Multi-Wi-Fi Aggregator, Channel Bonding & Policy Router GUI
"""

import sys
import os
import time
import threading
import tkinter as tk
from tkinter import messagebox
import customtkinter as ctk

from net_fusion_engine import NetFusionEngine, set_windows_system_proxy

ctk.set_appearance_mode("Dark")
ctk.set_default_color_theme("blue")

BASE_DIR = os.path.dirname(os.path.abspath(__file__))


def format_bytes(b):
    if b >= 1024**3:
        return f"{b / (1024**3):.2f} GB"
    elif b >= 1024**2:
        return f"{b / (1024**2):.1f} MB"
    elif b >= 1024:
        return f"{b / 1024:.1f} KB"
    else:
        return f"{int(b)} B"


def format_speed(bps):
    if bps >= 1024**2:
        return f"{bps / (1024**2):.2f} MB/s"
    elif bps >= 1024:
        return f"{bps / 1024:.1f} KB/s"
    else:
        return f"{int(bps)} B/s"


class NetFusionApp(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title("NetFusion - Multi-Wi-Fi Aggregator & Policy Router")
        self.geometry("980x760")
        self.minsize(900, 700)

        # Set window icon
        ico_path = os.path.join(BASE_DIR, "net_guardian.ico")
        if os.path.exists(ico_path):
            try:
                self.iconbitmap(ico_path)
            except Exception:
                pass

        # Core Engine
        self.engine = NetFusionEngine()
        self.proxy_enabled = False
        self.last_stats = {"primary": 0, "secondary": 0}
        self.last_tick = time.time()

        # Build UI
        self.setup_ui()

        # Auto-detect and populate network interfaces
        self.refresh_interfaces()

        # Start NetFusion Engine
        self.engine.start()

        # Periodic UI update
        self.update_live_stats()

        # Clean exit hook
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def setup_ui(self):
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # 1. Header Frame
        header = ctk.CTkFrame(self, corner_radius=12, fg_color="#181a20")
        header.grid(row=0, column=0, padx=16, pady=(14, 8), sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=0, padx=16, pady=12, sticky="w")

        title_lbl = ctk.CTkLabel(title_box, text="⚡ NetFusion Studio", font=ctk.CTkFont(size=22, weight="bold"), text_color="#00d2ff")
        title_lbl.pack(anchor="w")

        sub_lbl = ctk.CTkLabel(title_box, text="Multi-Wi-Fi Channel Bonding, Failover & Policy Router", font=ctk.CTkFont(size=12), text_color="#8892b0")
        sub_lbl.pack(anchor="w")

        # System Proxy Toggle Button in Header
        proxy_box = ctk.CTkFrame(header, fg_color="transparent")
        proxy_box.grid(row=0, column=1, padx=16, pady=10, sticky="e")

        self.proxy_status_badge = ctk.CTkLabel(proxy_box, text="SYSTEM PROXY: OFF", font=ctk.CTkFont(size=11, weight="bold"),
                                              fg_color="#3a2022", text_color="#ff6b6b", corner_radius=8, padx=10, pady=4)
        self.proxy_status_badge.pack(side="left", padx=10)

        self.proxy_toggle_btn = ctk.CTkButton(proxy_box, text="Turn Proxy ON", width=130, height=32,
                                             fg_color="#10b981", hover_color="#059669", command=self.toggle_system_proxy)
        self.proxy_toggle_btn.pack(side="left")

        # 2. Mode Selector Bar
        mode_frame = ctk.CTkFrame(self, corner_radius=12, fg_color="#1a1c23")
        mode_frame.grid(row=1, column=0, padx=16, pady=6, sticky="ew")
        mode_frame.grid_columnconfigure((0, 1), weight=1)

        self.mode_var = ctk.StringVar(value="BOOST")

        # Boost Mode Button Card
        self.boost_card = ctk.CTkFrame(mode_frame, fg_color="#202b3a", corner_radius=10, border_width=2, border_color="#00d2ff")
        self.boost_card.grid(row=0, column=0, padx=12, pady=10, sticky="nsew")

        b_title = ctk.CTkRadioButton(self.boost_card, text="⚡ Boost Mode (Channel Bonding)", variable=self.mode_var, value="BOOST",
                                     command=self.on_mode_change, font=ctk.CTkFont(size=14, weight="bold"), text_color="#00d2ff")
        b_title.pack(anchor="w", padx=14, pady=(10, 4))

        b_desc = ctk.CTkLabel(self.boost_card, text="Combines available Wi-Fi networks to maximize throughput across parallel streams,\nenhance connection stability, and provide seamless sub-second failover.",
                              font=ctk.CTkFont(size=11), text_color="#a0aec0", justify="left")
        b_desc.pack(anchor="w", padx=14, pady=(0, 10))

        # Control Mode Button Card
        self.control_card = ctk.CTkFrame(mode_frame, fg_color="#1c1f26", corner_radius=10, border_width=1, border_color="#333a48")
        self.control_card.grid(row=0, column=1, padx=12, pady=10, sticky="nsew")

        c_title = ctk.CTkRadioButton(self.control_card, text="🎛️ Control Mode (Traffic Steering)", variable=self.mode_var, value="CONTROL",
                                     command=self.on_mode_change, font=ctk.CTkFont(size=14, weight="bold"), text_color="#e2e8f0")
        c_title.pack(anchor="w", padx=14, pady=(10, 4))

        c_desc = ctk.CTkLabel(self.control_card, text="Policy routing: dedicate Wi-Fi 2 exclusively to low-latency calls, Discord & games,\nwhile bulk web and heavy downloads are routed via Wi-Fi 1.",
                              font=ctk.CTkFont(size=11), text_color="#a0aec0", justify="left")
        c_desc.pack(anchor="w", padx=14, pady=(0, 10))

        # 3. Dual Interface Status Cards
        interfaces_frame = ctk.CTkFrame(self, corner_radius=12, fg_color="#1a1c23")
        interfaces_frame.grid(row=2, column=0, padx=16, pady=6, sticky="ew")
        interfaces_frame.grid_columnconfigure((0, 1), weight=1)

        # Wi-Fi 1 Card
        self.card1 = ctk.CTkFrame(interfaces_frame, corner_radius=10, fg_color="#14161c")
        self.card1.grid(row=0, column=0, padx=12, pady=12, sticky="nsew")

        c1_head = ctk.CTkFrame(self.card1, fg_color="transparent")
        c1_head.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(c1_head, text="📡 Primary Interface (Wi-Fi 1)", font=ctk.CTkFont(size=13, weight="bold"), text_color="#00d2ff").pack(side="left")
        self.c1_status = ctk.CTkLabel(c1_head, text="CONNECTED", font=ctk.CTkFont(size=10, weight="bold"),
                                      fg_color="#103a20", text_color="#00ff88", corner_radius=6, padx=8, pady=2)
        self.c1_status.pack(side="right")

        self.c1_menu = ctk.CTkOptionMenu(self.card1, values=["Searching..."], command=self.on_select_primary, height=28)
        self.c1_menu.pack(fill="x", padx=12, pady=4)

        self.c1_stats_lbl = ctk.CTkLabel(self.card1, text="IP: None  |  Ping: -- ms  |  Speed: 0.00 MB/s",
                                         font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.c1_stats_lbl.pack(anchor="w", padx=12, pady=(2, 10))

        # Wi-Fi 2 Card
        self.card2 = ctk.CTkFrame(interfaces_frame, corner_radius=10, fg_color="#14161c")
        self.card2.grid(row=0, column=1, padx=12, pady=12, sticky="nsew")

        c2_head = ctk.CTkFrame(self.card2, fg_color="transparent")
        c2_head.pack(fill="x", padx=12, pady=(10, 4))
        ctk.CTkLabel(c2_head, text="📡 Secondary Interface (Wi-Fi 2 / USB Tether)", font=ctk.CTkFont(size=13, weight="bold"), text_color="#ffbe0b").pack(side="left")
        self.c2_status = ctk.CTkLabel(c2_head, text="STANDBY / OPTIONAL", font=ctk.CTkFont(size=10, weight="bold"),
                                      fg_color="#2b2d42", text_color="#a0aec0", corner_radius=6, padx=8, pady=2)
        self.c2_status.pack(side="right")

        self.c2_menu = ctk.CTkOptionMenu(self.card2, values=["None / Add 2nd Wi-Fi"], command=self.on_select_secondary, height=28)
        self.c2_menu.pack(fill="x", padx=12, pady=4)

        self.c2_stats_lbl = ctk.CTkLabel(self.card2, text="IP: None  |  Ping: -- ms  |  Speed: 0.00 MB/s",
                                         font=ctk.CTkFont(size=11), text_color="#a0aec0")
        self.c2_stats_lbl.pack(anchor="w", padx=12, pady=(2, 10))

        # 4. Lower Dashboard & Hardware Guide
        lower_frame = ctk.CTkFrame(self, corner_radius=12, fg_color="#1a1c23")
        lower_frame.grid(row=3, column=0, padx=16, pady=(6, 14), sticky="nsew")
        lower_frame.grid_columnconfigure((0, 1), weight=1)
        lower_frame.grid_rowconfigure(0, weight=1)

        # Combined Throughput Gauge & Actions
        dash_left = ctk.CTkFrame(lower_frame, fg_color="#14161c", corner_radius=10)
        dash_left.grid(row=0, column=0, padx=12, pady=12, sticky="nsew")

        ctk.CTkLabel(dash_left, text="🚀 Combined Throughput Monitor", font=ctk.CTkFont(size=14, weight="bold")).pack(anchor="w", padx=14, pady=(12, 4))

        self.combined_speed_lbl = ctk.CTkLabel(dash_left, text="0.00 MB/s", font=ctk.CTkFont(size=28, weight="bold"), text_color="#00ff88")
        self.combined_speed_lbl.pack(anchor="w", padx=14, pady=2)

        self.breakdown_lbl = ctk.CTkLabel(dash_left, text="Wi-Fi 1: 0.00 MB/s  +  Wi-Fi 2: 0.00 MB/s", font=ctk.CTkFont(size=12), text_color="#8892b0")
        self.breakdown_lbl.pack(anchor="w", padx=14, pady=(0, 10))

        # Progress Meter for Bonded Activity
        self.boost_meter = ctk.CTkProgressBar(dash_left, height=12, corner_radius=6, progress_color="#00d2ff", fg_color="#2b2d42")
        self.boost_meter.pack(fill="x", padx=14, pady=6)
        self.boost_meter.set(0)

        # Action Buttons
        btn_box = ctk.CTkFrame(dash_left, fg_color="transparent")
        btn_box.pack(fill="x", padx=14, pady=12)

        ref_btn = ctk.CTkButton(btn_box, text="🔄 Rescan Adapters", width=130, height=30,
                                fg_color="#2b6cb0", hover_color="#2c5282", command=self.refresh_interfaces)
        ref_btn.pack(side="left", padx=(0, 8))

        # Instructions / Hardware Setup Card
        dash_right = ctk.CTkFrame(lower_frame, fg_color="#14161c", corner_radius=10)
        dash_right.grid(row=0, column=1, padx=12, pady=12, sticky="nsew")

        ctk.CTkLabel(dash_right, text="💡 How to Connect Multiple Wi-Fi Networks", font=ctk.CTkFont(size=13, weight="bold"), text_color="#ffbe0b").pack(anchor="w", padx=14, pady=(12, 6))

        guide_text = (
            "A standard PC contains 1 built-in Wi-Fi radio. To connect to 2 Wi-Fi\n"
            "networks simultaneously, use any of these simple setups:\n\n"
            "1. USB Wi-Fi Dongle:\n"
            "   Plug in a $5 USB Wi-Fi adapter. Connect your built-in Wi-Fi to\n"
            "   Network A, and the USB Wi-Fi to Network B.\n\n"
            "2. Phone USB Tethering:\n"
            "   Connect your smartphone to Wi-Fi B, plug it in via USB, and turn on\n"
            "   'USB Tethering'. It immediately shows up as a high-speed adapter!\n\n"
            "3. Wi-Fi + Ethernet / 4G Hotspot:\n"
            "   Combine your home Wi-Fi with an Ethernet cable or mobile data."
        )
        ctk.CTkLabel(dash_right, text=guide_text, font=ctk.CTkFont(size=11), text_color="#cbd5e0", justify="left").pack(anchor="w", padx=14, pady=4)

    def refresh_interfaces(self):
        """Scans and populates network adapters."""
        interfaces = self.engine.get_available_interfaces()
        self.detected_ifaces = interfaces

        if not interfaces:
            self.c1_menu.configure(values=["No Active Network Found"])
            self.c2_menu.configure(values=["No Active Network Found"])
            return

        options = [f"{iface['name']} ({iface['ip']})" for iface in interfaces]
        self.c1_menu.configure(values=options)

        c2_options = ["None (Single Adapter)"] + options
        self.c2_menu.configure(values=c2_options)

        # Select defaults
        if len(interfaces) >= 1:
            self.c1_menu.set(options[0])
            self.engine.primary_ip = interfaces[0]["ip"]
        if len(interfaces) >= 2:
            self.c2_menu.set(c2_options[2])
            self.engine.secondary_ip = interfaces[1]["ip"]
            self.c2_status.configure(text="CONNECTED", fg_color="#103a20", text_color="#00ff88")
        else:
            self.c2_menu.set(c2_options[0])
            self.engine.secondary_ip = None
            self.c2_status.configure(text="STANDBY / OPTIONAL", fg_color="#2b2d42", text_color="#a0aec0")

        self.engine.set_interfaces(self.engine.primary_ip, self.engine.secondary_ip)

    def on_select_primary(self, choice):
        for iface in self.detected_ifaces:
            if iface["ip"] in choice:
                self.engine.primary_ip = iface["ip"]
                self.engine.set_interfaces(self.engine.primary_ip, self.engine.secondary_ip)
                break

    def on_select_secondary(self, choice):
        if "None" in choice:
            self.engine.secondary_ip = None
            self.c2_status.configure(text="STANDBY / OPTIONAL", fg_color="#2b2d42", text_color="#a0aec0")
        else:
            for iface in self.detected_ifaces:
                if iface["ip"] in choice:
                    self.engine.secondary_ip = iface["ip"]
                    self.c2_status.configure(text="CONNECTED", fg_color="#103a20", text_color="#00ff88")
                    break
        self.engine.set_interfaces(self.engine.primary_ip, self.engine.secondary_ip)

    def on_mode_change(self):
        new_mode = self.mode_var.get()
        self.engine.mode = new_mode

        if new_mode == "BOOST":
            self.boost_card.configure(border_color="#00d2ff", border_width=2)
            self.control_card.configure(border_color="#333a48", border_width=1)
        else:
            self.boost_card.configure(border_color="#333a48", border_width=1)
            self.control_card.configure(border_color="#ffbe0b", border_width=2)

    def toggle_system_proxy(self):
        self.proxy_enabled = not self.proxy_enabled
        success = set_windows_system_proxy(enable=self.proxy_enabled, proxy_server=f"127.0.0.1:{self.engine.port}")
        if success:
            if self.proxy_enabled:
                self.proxy_status_badge.configure(text="SYSTEM PROXY: ACTIVE", fg_color="#103a20", text_color="#00ff88")
                self.proxy_toggle_btn.configure(text="Turn Proxy OFF", fg_color="#ef4444", hover_color="#dc2626")
            else:
                self.proxy_status_badge.configure(text="SYSTEM PROXY: OFF", fg_color="#3a2022", text_color="#ff6b6b")
                self.proxy_toggle_btn.configure(text="Turn Proxy ON", fg_color="#10b981", hover_color="#059669")
        else:
            messagebox.showerror("Error", "Could not modify Windows system proxy settings.")

    def update_live_stats(self):
        now = time.time()
        dt = max(1.0, now - self.last_tick)

        p_bytes = self.engine.stats["primary_bytes"]
        s_bytes = self.engine.stats["secondary_bytes"]

        delta_p = p_bytes - self.last_stats["primary"]
        delta_s = s_bytes - self.last_stats["secondary"]

        self.last_stats["primary"] = p_bytes
        self.last_stats["secondary"] = s_bytes
        self.last_tick = now

        speed_p = delta_p / dt
        speed_s = delta_s / dt
        total_speed = speed_p + speed_s

        # Update Card 1
        p_health = self.engine.interface_health.get(self.engine.primary_ip, {})
        p_ping = p_health.get("latency_ms", "--")
        self.c1_stats_lbl.configure(text=f"IP: {self.engine.primary_ip or 'None'}  |  Ping: {p_ping} ms  |  Speed: {format_speed(speed_p)}")

        # Update Card 2
        s_health = self.engine.interface_health.get(self.engine.secondary_ip, {})
        s_ping = s_health.get("latency_ms", "--") if self.engine.secondary_ip else "--"
        self.c2_stats_lbl.configure(text=f"IP: {self.engine.secondary_ip or 'None'}  |  Ping: {s_ping} ms  |  Speed: {format_speed(speed_s)}")

        # Update Combined Gauge
        self.combined_speed_lbl.configure(text=format_speed(total_speed))
        self.breakdown_lbl.configure(text=f"Wi-Fi 1: {format_speed(speed_p)}  +  Wi-Fi 2: {format_speed(speed_s)}")

        # Activity animation
        prog = min(1.0, total_speed / (10 * 1024 * 1024))
        self.boost_meter.set(prog)

        self.after(1000, self.update_live_stats)

    def on_close(self):
        # Automatically disable system proxy before exiting so internet stays direct
        if self.proxy_enabled:
            set_windows_system_proxy(enable=False)
        self.engine.stop()
        self.destroy()


if __name__ == "__main__":
    app = NetFusionApp()
    app.mainloop()
