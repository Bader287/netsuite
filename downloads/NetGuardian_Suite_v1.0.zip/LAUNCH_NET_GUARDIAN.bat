@echo off
title NetGuardian Launcher
cd /d "%~dp0"

:: Use the Python 3.14 launcher
py "%~dp0net_guardian_app.py"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited or encountered an issue.
    pause
)
