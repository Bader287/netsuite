@echo off
title NetFusion Launcher
cd /d "%~dp0"

py "%~dp0net_fusion_app.py"
if %ERRORLEVEL% NEQ 0 (
    echo.
    echo Application exited or encountered an error.
    pause
)
