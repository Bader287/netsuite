# Project Management Study Materials

Organized study materials for Chapters 4 and 5, divided into Course Notes, Comprehensive Resumes with Exam Review Notes, and Solved Exercises.

---

## 📁 Directory Structure

```
project management/
├── Chapter_4_Risk_Management/
│   ├── 01_Course.pdf                      # Full theory, frameworks & Lotus Riverside case study (17 pages)
│   ├── 02_Resume_and_Review_Notes.pdf     # Master review guide, glossary, formulas, traps & self-test (4 pages)
│   └── 03_Exercises_with_Solutions.pdf    # Solved calculation exercises, exam quiz & model answers (7 pages)
│
├── Chapter_5_Cost_Estimation_and_Budgeting/
│   ├── 01_Course.pdf                      # Full theory, labor multipliers, learning curves & budgets (14 pages)
│   ├── 02_Resume_and_Review_Notes.pdf     # Master review guide, glossary, formulas, traps & self-test (4 pages)
│   └── 03_Exercises_with_Solutions.pdf    # Solved calculation exercises, exam quiz & model answers (7 pages)
│
└── Original_Packs/
    ├── Chapter_4_Risk_Management_Study_Pack.pdf
    └── Chapter_5_Cost_Estimation_and_Budgeting_Study_Pack.pdf
```

---

## 📑 Contents by Chapter

### Chapter 4: Project Risk Management
* [01_Course.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_4_Risk_Management/01_Course.pdf): Comprehensive syllabus coverage including Sections 1 through 10, probability-impact matrix, quantitative RF scoring, 4 risk response strategies, contingency management, and the forensic Lotus Riverside disaster analysis.
* [02_Resume_and_Review_Notes.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_4_Risk_Management/02_Resume_and_Review_Notes.pdf): Executive summary, 5 risk families matrix, RF formula and thresholds, response comparison table, Lotus Riverside case summary, academic glossary, exam pitfalls, 15 diagnostic self-test questions, and model evaluation criteria.
* [03_Exercises_with_Solutions.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_4_Risk_Management/03_Exercises_with_Solutions.pdf): Solved Exercises 1–8, 20 exam-style quiz questions (MCQs, True/False, Short Answer), and complete step-by-step solutions with grading rubrics.

### Chapter 5: Cost Estimation and Budgeting
* [01_Course.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_5_Cost_Estimation_and_Budgeting/01_Course.pdf): Comprehensive syllabus coverage including Sections 1 through 8, the 5-stage cost cycle, labor overhead multipliers, 4 cost classification pairs, 4 estimation accuracy tiers (±30%, ±15%, ±10%, ±5%), Wright's learning curve model ($Y_x = a X^b$), Top-Down vs. Bottom-Up budgeting, Activity-Based Costing (ABC), and variance control.
* [02_Resume_and_Review_Notes.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_5_Cost_Estimation_and_Budgeting/02_Resume_and_Review_Notes.pdf): Executive summary, labor formula breakdown, cost classification dimensions, planned overtime trap, learning curve doubling rules, ABC 4-step allocation, variance sign convention, academic glossary, exam pitfalls, 15 diagnostic self-test questions, and model evaluation criteria.
* [03_Exercises_with_Solutions.pdf](file:///c:/Users/bader/Documents/antigravity/project%20management/Chapter_5_Cost_Estimation_and_Budgeting/03_Exercises_with_Solutions.pdf): Solved Exercises 1–9, 20 exam-style quiz questions (MCQs, True/False, Short Answer), and complete step-by-step solutions with grading rubrics.
