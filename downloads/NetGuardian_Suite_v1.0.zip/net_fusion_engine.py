"""
NetFusion Core Engine
Multi-Interface Dispatch Proxy, Channel Bonding, and Policy-Based Routing.
Supports Boost Mode (Multi-Socket Bonding + Failover) and Control Mode (Traffic Steering).
"""

import sys
import os
import socket
import select
import threading
import time
import urllib.request
import subprocess
import psutil

if sys.platform == "win32":
    try:
        import winreg
    except ImportError:
        winreg = None
else:
    winreg = None

class NetFusionEngine:
    def __init__(self, host="127.0.0.1", port=8888):
        self.host = host
        self.port = port
        self.running = False
        self.server_socket = None
        self.thread = None

        # Operational Mode: 'BOOST' or 'CONTROL'
        self.mode = "BOOST"

        # Selected interface IP addresses
        self.primary_ip = None      # e.g., Wi-Fi 1
        self.secondary_ip = None    # e.g., Wi-Fi 2 or USB Tether
        self.rr_index = 0
        self.lock = threading.Lock()

        # Interface health metrics
        self.interface_health = {}  # ip -> {"latency_ms": 0, "alive": True}

        # Stats
        self.stats = {
            "primary_bytes": 0,
            "secondary_bytes": 0,
            "total_connections": 0
        }

    def get_available_interfaces(self):
        """Returns list of active network interfaces with valid non-loopback IPv4 addresses."""
        result = []
        stats = psutil.net_if_stats()
        addrs = psutil.net_if_addrs()

        for nic_name, nic_addrs in addrs.items():
            stat = stats.get(nic_name)
            if not stat or not stat.isup:
                continue

            for addr in nic_addrs:
                if addr.family == socket.AF_INET and not addr.address.startswith("127.") and not addr.address.startswith("169.254."):
                    result.append({
                        "name": nic_name,
                        "ip": addr.address,
                        "speed": stat.speed,
                        "status": "Up"
                    })
        return result

    def set_interfaces(self, primary_ip, secondary_ip=None):
        with self.lock:
            self.primary_ip = primary_ip
            self.secondary_ip = secondary_ip
            if primary_ip:
                self.interface_health[primary_ip] = {"latency_ms": 15, "alive": True}
            if secondary_ip:
                self.interface_health[secondary_ip] = {"latency_ms": 20, "alive": True}

    def start(self):
        if self.running:
            return
        self.running = True
        self.server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        self.server_socket.bind((self.host, self.port))
        self.server_socket.listen(256)

        self.thread = threading.Thread(target=self._accept_loop, daemon=True)
        self.thread.start()

        # Start health check watchdog
        self.watchdog_thread = threading.Thread(target=self._health_watchdog, daemon=True)
        self.watchdog_thread.start()

    def stop(self):
        self.running = False
        if self.server_socket:
            try:
                self.server_socket.close()
            except Exception:
                pass

    def _select_outbound_ip(self, dest_port=80):
        """Chooses the outbound interface based on current operational mode."""
        with self.lock:
            # If only primary is available, fallback to primary
            if not self.secondary_ip or not self.interface_health.get(self.secondary_ip, {}).get("alive", False):
                return self.primary_ip, "Primary (Fallback)"

            if not self.primary_ip or not self.interface_health.get(self.primary_ip, {}).get("alive", False):
                return self.secondary_ip, "Secondary (Fallback)"

            # BOOST MODE: Round-robin across active interfaces for maximum throughput
            if self.mode == "BOOST":
                self.rr_index += 1
                if self.rr_index % 2 == 0:
                    return self.primary_ip, "Primary (Boost)"
                else:
                    return self.secondary_ip, "Secondary (Boost)"

            # CONTROL MODE: Policy-based routing
            # Low-latency voice/chat/interactive ports -> Secondary (e.g. Wi-Fi 2)
            # Bulk HTTP/HTTPS download traffic -> Primary (e.g. Wi-Fi 1)
            elif self.mode == "CONTROL":
                # Gaming / Voice / Streaming ports (Discord, TeamSpeak, games)
                low_latency_ports = {53, 123, 1935, 5060, 64738, 9987, 27015, 3074}
                if dest_port in low_latency_ports:
                    return self.secondary_ip, "Secondary (Low-Latency)"
                else:
                    return self.primary_ip, "Primary (Bulk Traffic)"

            return self.primary_ip, "Primary"

    def _accept_loop(self):
        while self.running:
            try:
                client_sock, client_addr = self.server_socket.accept()
                threading.Thread(target=self._handle_client, args=(client_sock,), daemon=True).start()
            except Exception:
                break

    def _handle_client(self, client_sock):
        try:
            client_sock.settimeout(10)
            req_data = client_sock.recv(4096)
            if not req_data:
                client_sock.close()
                return

            req_line = req_data.split(b"\r\n")[0].decode("latin-1", errors="ignore")
            parts = req_line.split()
            if len(parts) < 2:
                client_sock.close()
                return

            method, target = parts[0], parts[1]

            # HTTP CONNECT Tunneling (for HTTPS traffic)
            if method.upper() == "CONNECT":
                host, port_str = target.split(":")
                dest_port = int(port_str)
                out_ip, route_name = self._select_outbound_ip(dest_port)

                out_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                out_sock.settimeout(10)
                try:
                    out_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    client_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except Exception:
                    pass

                if out_ip:
                    try:
                        out_sock.bind((out_ip, 0))
                    except Exception:
                        pass

                try:
                    out_sock.connect((host, dest_port))
                    client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                    self._pipe_sockets(client_sock, out_sock, out_ip)
                except Exception:
                    # Automatic Failover to secondary if primary connection failed!
                    if out_ip == self.primary_ip and self.secondary_ip:
                        try:
                            failover_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                            failover_sock.bind((self.secondary_ip, 0))
                            failover_sock.connect((host, dest_port))
                            client_sock.sendall(b"HTTP/1.1 200 Connection Established\r\n\r\n")
                            self._pipe_sockets(client_sock, failover_sock, self.secondary_ip)
                            return
                        except Exception:
                            pass
                    client_sock.close()
                    out_sock.close()

            # Plain HTTP Proxying
            else:
                # Parse host from headers
                dest_host = None
                dest_port = 80
                for line in req_data.split(b"\r\n"):
                    if line.lower().startswith(b"host:"):
                        host_part = line.split(b":", 1)[1].strip().decode("latin-1")
                        if ":" in host_part:
                            dest_host, port_str = host_part.split(":")
                            dest_port = int(port_str)
                        else:
                            dest_host = host_part
                        break

                if not dest_host:
                    client_sock.close()
                    return

                out_ip, _ = self._select_outbound_ip(dest_port)
                out_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                out_sock.settimeout(10)
                try:
                    out_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                    client_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
                except Exception:
                    pass

                if out_ip:
                    try:
                        out_sock.bind((out_ip, 0))
                    except Exception:
                        pass

                try:
                    out_sock.connect((dest_host, dest_port))
                    out_sock.sendall(req_data)
                    self._pipe_sockets(client_sock, out_sock, out_ip)
                except Exception:
                    client_sock.close()
                    out_sock.close()

        except Exception:
            try:
                client_sock.close()
            except Exception:
                pass

    def _pipe_sockets(self, s1, s2, outbound_ip):
        """Bidirectional transfer between client and destination server."""
        sockets = [s1, s2]
        s1.setblocking(False)
        s2.setblocking(False)

        while self.running:
            try:
                readable, _, exceptional = select.select(sockets, [], sockets, 20.0)
                if exceptional or not readable:
                    break

                for s in readable:
                    data = s.recv(65536)
                    if not data:
                        return
                    other = s2 if s is s1 else s1
                    other.sendall(data)

                    # Update throughput stats
                    with self.lock:
                        if outbound_ip == self.primary_ip:
                            self.stats["primary_bytes"] += len(data)
                        elif outbound_ip == self.secondary_ip:
                            self.stats["secondary_bytes"] += len(data)
            except Exception:
                break
        try:
            s1.close()
            s2.close()
        except Exception:
            pass

    def _health_watchdog(self):
        """Monitors responsiveness and latency across interfaces for auto-failover."""
        while self.running:
            time.sleep(4.0)
            for ip in [self.primary_ip, self.secondary_ip]:
                if not ip:
                    continue
                try:
                    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                    s.settimeout(2.0)
                    s.bind((ip, 0))
                    t0 = time.time()
                    s.connect(("1.1.1.1", 53))
                    latency = (time.time() - t0) * 1000.0
                    s.close()
                    with self.lock:
                        self.interface_health[ip] = {"latency_ms": round(latency, 1), "alive": True}
                except Exception:
                    with self.lock:
                        self.interface_health[ip] = {"latency_ms": 999, "alive": False}


# Cross-Platform System Proxy Controller Utility (Windows, macOS, Linux)
def set_system_proxy(enable=True, proxy_server="127.0.0.1:8888"):
    host, port = proxy_server.split(":")

    # 1. Windows Implementation
    if sys.platform == "win32" and winreg:
        try:
            import ctypes
            reg_key = winreg.OpenKey(
                winreg.HKEY_CURRENT_USER,
                r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
                0,
                winreg.KEY_SET_VALUE
            )
            winreg.SetValueEx(reg_key, "ProxyEnable", 0, winreg.REG_DWORD, 1 if enable else 0)
            if enable:
                winreg.SetValueEx(reg_key, "ProxyServer", 0, winreg.REG_SZ, proxy_server)
            winreg.CloseKey(reg_key)

            # Broadcast change to Windows WinINet (Edge, Chrome, system apps)
            INTERNET_OPTION_SETTINGS_CHANGED = 39
            INTERNET_OPTION_REFRESH = 37
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
            ctypes.windll.wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
            return True
        except Exception as e:
            print("Failed to configure Windows proxy:", e)
            return False

    # 2. macOS Implementation (networksetup)
    elif sys.platform == "darwin":
        try:
            state = "on" if enable else "off"
            subprocess.run(["networksetup", "-setwebproxystate", "Wi-Fi", state], check=False)
            subprocess.run(["networksetup", "-setsecurewebproxystate", "Wi-Fi", state], check=False)
            if enable:
                subprocess.run(["networksetup", "-setwebproxy", "Wi-Fi", host, port], check=False)
                subprocess.run(["networksetup", "-setsecurewebproxy", "Wi-Fi", host, port], check=False)
            return True
        except Exception as e:
            print("Failed to configure macOS proxy:", e)
            return False

    # 3. Linux Implementation (GNOME / gsettings)
    elif sys.platform.startswith("linux"):
        try:
            if enable:
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy", "mode", "manual"], check=False)
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy.http", "host", host], check=False)
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy.http", "port", port], check=False)
            else:
                subprocess.run(["gsettings", "set", "org.gnome.system.proxy", "mode", "none"], check=False)
            return True
        except Exception as e:
            print("Failed to configure Linux proxy:", e)
            return False

    return False

# Backward-compatible alias
set_windows_system_proxy = set_system_proxy
